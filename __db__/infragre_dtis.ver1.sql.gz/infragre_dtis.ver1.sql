-- phpMyAdmin SQL Dump
-- version 4.0.10deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 09, 2018 at 01:41 PM
-- Server version: 5.5.61-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.26

--
-- DonsolTIS ver1
--
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `infragre_dtis`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--
-- Creation: Jul 30, 2018 at 10:17 PM
--

CREATE TABLE IF NOT EXISTS `audit_trail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_id` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `user` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activity` char(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'created, modified',
  `mod_details` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- Dumping data for table `audit_trail`
--

INSERT INTO `audit_trail` (`id`, `visitor_id`, `visit_id`, `user`, `timestamp`, `activity`, `mod_details`) VALUES
(1, 1, NULL, 'DTISDev', '2018-04-28 05:49:53', 'modified', 'field: h_address, old value: Atherton, QLD 4883\r\nAustralia, new value: Atherton, QLD 4883Australia | field: remarks, old value: , new value: asdf | '),
(2, 1, NULL, 'DTISDev', '2018-04-28 07:26:22', 'modified', 'field: remarks, old value: asdf, new value:  | '),
(3, 2, NULL, 'DTISDev', '2018-04-28 07:36:26', 'modified', 'field: h_address, old value: Atherton, QLD 4883\r\nAustralia, new value: Atherton, QLD 4883Australia | field: remarks, old value: , new value: Stella is a naturalized German by virtue of her marriage to Yogi | '),
(4, 2, NULL, 'DTISDev', '2018-04-28 07:40:29', 'modified', 'field: remarks, old value: Stella is a naturalized German by virtue of her marriage to Yogi, new value:  | '),
(5, 2, NULL, 'DTISDev', '2018-04-28 07:41:38', 'modified', 'no evident changes'),
(6, 1, NULL, 'DTISDev', '2018-04-28 07:51:56', 'modified', 'no evident changes'),
(7, 1, NULL, 'DTISDev', '2018-04-28 07:53:42', 'modified', 'field: mname, old value: , new value: X | '),
(8, 1, NULL, 'DTISDev', '2018-04-28 08:02:03', 'modified', 'field: b_address, old value: Atherton, QLD 4883\r\nAustralia, new value: Atherton, QLD 4883Australia | field: remarks, old value: , new value: asdf | '),
(9, 3, NULL, 'DTISDev', '2018-04-28 08:41:09', 'created', ''),
(10, 4, NULL, 'DTISDev', '2018-04-29 04:23:27', 'created', ''),
(11, 2, NULL, 'DTISDev', '2018-04-29 06:46:54', 'modified', 'field: b_address, old value: Atherton, QLD 4883\r\nAustralia, new value: Atherton, QLD 4883Australia | field: ice_address, old value: Atherton, QLD 4883\r\nAustralia, new value: Atherton, QLD 4883Australia | field: remarks, old value: , new value: Asdf | '),
(12, 2, NULL, 'DTISDev', '2018-04-29 06:47:24', 'modified', 'field: remarks, old value: Asdf, new value: Lorem ipsum dolor consectitur sit amet | '),
(13, 4, NULL, 'DTISDev', '2018-04-29 06:48:39', 'modified', 'no evident changes'),
(14, 4, NULL, 'DTISDev', '2018-04-29 06:52:23', 'modified', 'entry marked as deleted'),
(15, 4, NULL, 'DTISDev', '2018-04-29 06:53:36', 'modified', 'entry restored'),
(16, 5, NULL, 'Partner1', '2018-08-19 01:38:09', 'created', ''),
(17, NULL, NULL, 'DTISDev', '2018-08-19 12:44:22', 'created', ''),
(18, NULL, NULL, 'DTISDev', '2018-08-19 12:58:02', 'created', ''),
(19, NULL, NULL, 'DTISDev', '2018-08-19 12:59:01', 'modified', 'no evident changes'),
(20, NULL, NULL, 'DTISDev', '2018-08-19 12:59:20', 'modified', 'no evident changes'),
(21, NULL, NULL, 'DTISDev', '2018-08-19 12:59:51', 'modified', 'no evident changes'),
(22, NULL, NULL, 'DTISDev', '2018-08-19 13:00:18', 'modified', 'no evident changes'),
(23, NULL, NULL, 'DTISDev', '2018-08-19 13:01:58', 'modified', 'no evident changes'),
(24, NULL, NULL, 'DTISDev', '2018-08-19 13:03:29', 'modified', 'entry marked as deleted'),
(25, NULL, NULL, 'DTISDev', '2018-08-19 13:06:17', 'modified', 'no evident changes'),
(26, NULL, NULL, 'DTISDev', '2018-08-19 13:07:40', 'modified', 'no evident changes'),
(27, NULL, NULL, 'DTISDev', '2018-08-19 13:08:35', 'modified', 'entry marked as deleted'),
(28, NULL, NULL, 'DTISDev', '2018-08-19 13:08:40', 'modified', 'no evident changes'),
(29, NULL, NULL, 'DTISDev', '2018-08-19 13:22:09', 'modified', 'no evident changes'),
(30, NULL, NULL, 'DTISDev', '2018-08-19 13:24:21', 'modified', 'no evident changes'),
(31, NULL, NULL, 'DTISDev', '2018-08-19 13:24:42', 'modified', 'entry marked as deleted'),
(32, 106, NULL, 'DTISDev', '2018-08-19 16:48:20', 'created', ''),
(33, 107, NULL, 'DTISDev', '2018-08-19 17:15:26', 'created', ''),
(34, NULL, 501, 'DTISDev', '2018-08-19 18:29:14', 'created', ''),
(35, NULL, 502, 'DTISDev', '2018-08-19 18:30:10', 'created', ''),
(36, NULL, 503, 'DTISDev', '2018-08-19 18:31:36', 'created', ''),
(37, NULL, 501, 'DTISDev', '2018-08-19 19:19:38', 'modified', 'field: visit_remarks, old value: Accompanied by adult, new value: Accompanied by guardian | '),
(38, NULL, 501, 'DTISDev', '2018-08-19 19:20:32', 'modified', 'field: visit_remarks, old value: Accompanied by adult, new value: Accompanied by guardian | '),
(39, NULL, 502, 'DTISDev', '2018-08-19 19:24:53', 'modified', 'field: visit_remarks, old value: Accompanied by adult, new value: Accompanied by guardian | '),
(40, NULL, 502, 'DTISDev', '2018-08-19 19:25:32', 'modified', 'field: visit_remarks, old value: Accompanied by adult, new value: Accompanied by guardian | '),
(41, NULL, 501, 'DTISDev', '2018-08-19 19:31:36', 'modified', 'field: boarding_pass, old value: , new value: XXXX | '),
(42, NULL, 502, 'DTISDev', '2018-08-19 19:52:44', 'deleted', 'entry marked as deleted'),
(43, NULL, 504, 'DTISDev', '2018-10-08 10:43:10', 'created', ''),
(44, 108, NULL, 'Partner1', '2018-10-08 15:55:36', 'created', ''),
(45, 108, NULL, 'DTISDev', '2018-10-08 15:58:43', 'modified', 'field: bdate, old value: 2018-10-08, new value: 2015-08-15 | field: remarks, old value: , new value: dupe | '),
(46, 108, NULL, 'DTISDev', '2018-10-08 15:59:14', 'modified', 'field: remarks, old value: dupe, new value: dupe; delete this | '),
(47, NULL, NULL, 'Partner1', '2018-10-08 16:22:39', 'created', 'via partner'),
(48, NULL, NULL, 'Partner1', '2018-10-08 16:28:16', 'created', 'via partner'),
(49, NULL, NULL, 'DTISDev', '2018-10-08 19:51:35', 'batch process', 'partner entries'),
(50, NULL, NULL, 'DTISDev', '2018-10-08 19:52:33', 'batch process', 'partner entries'),
(51, NULL, NULL, 'DTISDev', '2018-10-08 19:55:17', 'batch process', 'partner entries'),
(52, NULL, NULL, 'DTISDev', '2018-10-08 19:57:17', 'batch process', 'partner entries'),
(53, NULL, NULL, 'DTISDev', '2018-10-08 20:00:53', 'batch process', 'partner entries'),
(54, 112, NULL, 'DTISDev', '2018-10-08 20:02:48', 'modified', 'entry marked as deleted');

-- --------------------------------------------------------

--
-- Table structure for table `butanding_interaction`
--
-- Creation: Aug 19, 2018 at 01:47 PM
--

CREATE TABLE IF NOT EXISTS `butanding_interaction` (
  `interaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `boat_id` int(11) NOT NULL,
  `bio_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`interaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=231 ;

--
-- Dumping data for table `butanding_interaction`
--

INSERT INTO `butanding_interaction` (`interaction_id`, `visit_id`, `boat_id`, `bio_name`, `remarks`, `trash`) VALUES
(1, 1, 1, 'Juan dela Cruz', 'Asdf', 0),
(2, 2, 1, 'Juan dela Cruz', 'Asdf', 0),
(3, 3, 1, 'Juan dela Cruz', NULL, 0),
(4, 4, 2, 'Pedro Penduco', NULL, 0),
(5, 6, 1, 'Juan dela Cruz', NULL, 0),
(6, 7, 2, 'Pedro Penduco', NULL, 0),
(7, 8, 1, 'Juan dela Cruz', NULL, 0),
(8, 9, 2, 'Pedro Penduco', NULL, 0),
(9, 16, 1, 'Juan dela Cruz', NULL, 0),
(10, 17, 2, 'Pedro Penduco', NULL, 0),
(11, 18, 1, 'Juan dela Cruz', NULL, 0),
(12, 21, 2, 'Pedro Penduco', NULL, 0),
(13, 27, 1, 'Juan dela Cruz', NULL, 0),
(14, 30, 2, 'Pedro Penduco', NULL, 0),
(15, 33, 1, 'Juan dela Cruz', NULL, 0),
(16, 35, 2, 'Pedro Penduco', NULL, 0),
(17, 36, 1, 'Juan dela Cruz', NULL, 0),
(18, 37, 2, 'Pedro Penduco', NULL, 0),
(19, 40, 1, 'Juan dela Cruz', NULL, 0),
(20, 42, 2, 'Pedro Penduco', NULL, 0),
(21, 45, 1, 'Juan dela Cruz', NULL, 0),
(22, 46, 2, 'Pedro Penduco', NULL, 0),
(23, 47, 1, 'Juan dela Cruz', NULL, 0),
(24, 49, 2, 'Pedro Penduco', NULL, 0),
(25, 50, 1, 'Juan dela Cruz', NULL, 0),
(26, 51, 2, 'Pedro Penduco', NULL, 0),
(27, 52, 1, 'Juan dela Cruz', NULL, 0),
(28, 56, 2, 'Pedro Penduco', NULL, 0),
(29, 58, 1, 'Juan dela Cruz', NULL, 0),
(30, 61, 2, 'Pedro Penduco', NULL, 0),
(31, 63, 1, 'Juan dela Cruz', NULL, 0),
(32, 64, 2, 'Pedro Penduco', NULL, 0),
(33, 68, 1, 'Juan dela Cruz', NULL, 0),
(34, 71, 2, 'Pedro Penduco', NULL, 0),
(35, 73, 1, 'Juan dela Cruz', NULL, 0),
(36, 74, 2, 'Pedro Penduco', NULL, 0),
(37, 75, 1, 'Juan dela Cruz', NULL, 0),
(38, 77, 2, 'Pedro Penduco', NULL, 0),
(39, 78, 1, 'Juan dela Cruz', NULL, 0),
(40, 79, 2, 'Pedro Penduco', NULL, 0),
(41, 82, 1, 'Juan dela Cruz', NULL, 0),
(42, 83, 2, 'Pedro Penduco', NULL, 0),
(43, 84, 1, 'Juan dela Cruz', NULL, 0),
(44, 88, 2, 'Pedro Penduco', NULL, 0),
(45, 89, 1, 'Juan dela Cruz', NULL, 0),
(46, 90, 2, 'Pedro Penduco', NULL, 0),
(47, 91, 1, 'Juan dela Cruz', NULL, 0),
(48, 92, 2, 'Pedro Penduco', NULL, 0),
(49, 93, 1, 'Juan dela Cruz', NULL, 0),
(50, 95, 2, 'Pedro Penduco', NULL, 0),
(51, 97, 1, 'Juan dela Cruz', NULL, 0),
(52, 98, 2, 'Pedro Penduco', NULL, 0),
(53, 99, 1, 'Juan dela Cruz', NULL, 0),
(54, 102, 2, 'Pedro Penduco', NULL, 0),
(55, 103, 1, 'Juan dela Cruz', NULL, 0),
(56, 104, 2, 'Pedro Penduco', NULL, 0),
(57, 105, 1, 'Juan dela Cruz', NULL, 0),
(58, 108, 2, 'Pedro Penduco', NULL, 0),
(59, 111, 1, 'Juan dela Cruz', NULL, 0),
(60, 115, 2, 'Pedro Penduco', NULL, 0),
(61, 116, 1, 'Juan dela Cruz', NULL, 0),
(62, 118, 2, 'Pedro Penduco', NULL, 0),
(63, 119, 1, 'Juan dela Cruz', NULL, 0),
(64, 125, 2, 'Pedro Penduco', NULL, 0),
(65, 127, 1, 'Juan dela Cruz', NULL, 0),
(66, 128, 2, 'Pedro Penduco', NULL, 0),
(67, 132, 1, 'Juan dela Cruz', NULL, 0),
(68, 138, 2, 'Pedro Penduco', NULL, 0),
(69, 143, 1, 'Juan dela Cruz', NULL, 0),
(70, 147, 2, 'Pedro Penduco', NULL, 0),
(71, 148, 1, 'Juan dela Cruz', NULL, 0),
(72, 149, 2, 'Pedro Penduco', NULL, 0),
(73, 150, 1, 'Juan dela Cruz', NULL, 0),
(74, 152, 2, 'Pedro Penduco', NULL, 0),
(75, 155, 1, 'Juan dela Cruz', NULL, 0),
(76, 157, 2, 'Pedro Penduco', NULL, 0),
(77, 161, 1, 'Juan dela Cruz', NULL, 0),
(78, 162, 2, 'Pedro Penduco', NULL, 0),
(79, 163, 1, 'Juan dela Cruz', NULL, 0),
(80, 165, 2, 'Pedro Penduco', NULL, 0),
(81, 167, 1, 'Juan dela Cruz', NULL, 0),
(82, 168, 2, 'Pedro Penduco', NULL, 0),
(83, 170, 1, 'Juan dela Cruz', NULL, 0),
(84, 173, 2, 'Pedro Penduco', NULL, 0),
(85, 178, 1, 'Juan dela Cruz', NULL, 0),
(86, 180, 2, 'Pedro Penduco', NULL, 0),
(87, 181, 1, 'Juan dela Cruz', NULL, 0),
(88, 182, 2, 'Pedro Penduco', NULL, 0),
(89, 184, 1, 'Juan dela Cruz', NULL, 0),
(90, 186, 2, 'Pedro Penduco', NULL, 0),
(91, 187, 1, 'Juan dela Cruz', NULL, 0),
(92, 190, 2, 'Pedro Penduco', NULL, 0),
(93, 197, 1, 'Juan dela Cruz', NULL, 0),
(94, 200, 2, 'Pedro Penduco', NULL, 0),
(95, 202, 1, 'Juan dela Cruz', NULL, 0),
(96, 204, 2, 'Pedro Penduco', NULL, 0),
(97, 205, 1, 'Juan dela Cruz', NULL, 0),
(98, 206, 2, 'Pedro Penduco', NULL, 0),
(99, 207, 1, 'Juan dela Cruz', NULL, 0),
(100, 208, 2, 'Pedro Penduco', NULL, 0),
(101, 214, 1, 'Juan dela Cruz', NULL, 0),
(102, 216, 2, 'Pedro Penduco', NULL, 0),
(103, 217, 1, 'Juan dela Cruz', NULL, 0),
(104, 218, 2, 'Pedro Penduco', NULL, 0),
(105, 222, 1, 'Juan dela Cruz', NULL, 0),
(106, 223, 2, 'Pedro Penduco', NULL, 0),
(107, 225, 1, 'Juan dela Cruz', NULL, 0),
(108, 226, 2, 'Pedro Penduco', NULL, 0),
(109, 230, 1, 'Juan dela Cruz', NULL, 0),
(110, 232, 2, 'Pedro Penduco', NULL, 0),
(111, 233, 1, 'Juan dela Cruz', NULL, 0),
(112, 235, 2, 'Pedro Penduco', NULL, 0),
(113, 239, 1, 'Juan dela Cruz', NULL, 0),
(114, 241, 2, 'Pedro Penduco', NULL, 0),
(115, 242, 1, 'Juan dela Cruz', NULL, 0),
(116, 244, 2, 'Pedro Penduco', NULL, 0),
(117, 245, 1, 'Juan dela Cruz', NULL, 0),
(118, 246, 2, 'Pedro Penduco', NULL, 0),
(119, 249, 1, 'Juan dela Cruz', NULL, 0),
(120, 251, 2, 'Pedro Penduco', NULL, 0),
(121, 254, 1, 'Juan dela Cruz', NULL, 0),
(122, 258, 2, 'Pedro Penduco', NULL, 0),
(123, 261, 1, 'Juan dela Cruz', NULL, 0),
(124, 265, 2, 'Pedro Penduco', NULL, 0),
(125, 273, 1, 'Juan dela Cruz', NULL, 0),
(126, 275, 2, 'Pedro Penduco', NULL, 0),
(127, 276, 1, 'Juan dela Cruz', NULL, 0),
(128, 277, 2, 'Pedro Penduco', NULL, 0),
(129, 279, 1, 'Juan dela Cruz', NULL, 0),
(130, 280, 2, 'Pedro Penduco', NULL, 0),
(131, 284, 1, 'Juan dela Cruz', NULL, 0),
(132, 285, 2, 'Pedro Penduco', NULL, 0),
(133, 289, 1, 'Juan dela Cruz', NULL, 0),
(134, 292, 2, 'Pedro Penduco', NULL, 0),
(135, 293, 1, 'Juan dela Cruz', NULL, 0),
(136, 294, 2, 'Pedro Penduco', NULL, 0),
(137, 297, 1, 'Juan dela Cruz', NULL, 0),
(138, 298, 2, 'Pedro Penduco', NULL, 0),
(139, 300, 1, 'Juan dela Cruz', NULL, 0),
(140, 301, 2, 'Pedro Penduco', NULL, 0),
(141, 303, 1, 'Juan dela Cruz', NULL, 0),
(142, 304, 2, 'Pedro Penduco', NULL, 0),
(143, 306, 1, 'Juan dela Cruz', NULL, 0),
(144, 307, 2, 'Pedro Penduco', NULL, 0),
(145, 310, 1, 'Juan dela Cruz', NULL, 0),
(146, 315, 2, 'Pedro Penduco', NULL, 0),
(147, 316, 1, 'Juan dela Cruz', NULL, 0),
(148, 318, 2, 'Pedro Penduco', NULL, 0),
(149, 319, 1, 'Juan dela Cruz', NULL, 0),
(150, 324, 2, 'Pedro Penduco', NULL, 0),
(151, 326, 1, 'Juan dela Cruz', NULL, 0),
(152, 327, 2, 'Pedro Penduco', NULL, 0),
(153, 334, 1, 'Juan dela Cruz', NULL, 0),
(154, 335, 2, 'Pedro Penduco', NULL, 0),
(155, 336, 1, 'Juan dela Cruz', NULL, 0),
(156, 338, 2, 'Pedro Penduco', NULL, 0),
(157, 339, 1, 'Juan dela Cruz', NULL, 0),
(158, 341, 2, 'Pedro Penduco', NULL, 0),
(159, 343, 1, 'Juan dela Cruz', NULL, 0),
(160, 346, 2, 'Pedro Penduco', NULL, 0),
(161, 347, 1, 'Juan dela Cruz', NULL, 0),
(162, 349, 2, 'Pedro Penduco', NULL, 0),
(163, 353, 1, 'Juan dela Cruz', NULL, 0),
(164, 360, 2, 'Pedro Penduco', NULL, 0),
(165, 361, 1, 'Juan dela Cruz', NULL, 0),
(166, 363, 2, 'Pedro Penduco', NULL, 0),
(167, 364, 1, 'Juan dela Cruz', NULL, 0),
(168, 366, 2, 'Pedro Penduco', NULL, 0),
(169, 367, 1, 'Juan dela Cruz', NULL, 0),
(170, 368, 2, 'Pedro Penduco', NULL, 0),
(171, 370, 1, 'Juan dela Cruz', NULL, 0),
(172, 372, 2, 'Pedro Penduco', NULL, 0),
(173, 377, 1, 'Juan dela Cruz', NULL, 0),
(174, 378, 2, 'Pedro Penduco', NULL, 0),
(175, 380, 1, 'Juan dela Cruz', NULL, 0),
(176, 385, 2, 'Pedro Penduco', NULL, 0),
(177, 387, 1, 'Juan dela Cruz', NULL, 0),
(178, 393, 2, 'Pedro Penduco', NULL, 0),
(179, 397, 1, 'Juan dela Cruz', NULL, 0),
(180, 398, 2, 'Pedro Penduco', NULL, 0),
(181, 401, 1, 'Juan dela Cruz', NULL, 0),
(182, 406, 2, 'Pedro Penduco', NULL, 0),
(183, 407, 1, 'Juan dela Cruz', NULL, 0),
(184, 408, 2, 'Pedro Penduco', NULL, 0),
(185, 411, 1, 'Juan dela Cruz', NULL, 0),
(186, 415, 2, 'Pedro Penduco', NULL, 0),
(187, 416, 1, 'Juan dela Cruz', NULL, 0),
(188, 417, 2, 'Pedro Penduco', NULL, 0),
(189, 420, 1, 'Juan dela Cruz', NULL, 0),
(190, 422, 2, 'Pedro Penduco', NULL, 0),
(191, 423, 1, 'Juan dela Cruz', NULL, 0),
(192, 425, 2, 'Pedro Penduco', NULL, 0),
(193, 426, 1, 'Juan dela Cruz', NULL, 0),
(194, 431, 2, 'Pedro Penduco', NULL, 0),
(195, 434, 1, 'Juan dela Cruz', NULL, 0),
(196, 436, 2, 'Pedro Penduco', NULL, 0),
(197, 437, 1, 'Juan dela Cruz', NULL, 0),
(198, 438, 2, 'Pedro Penduco', NULL, 0),
(199, 440, 1, 'Juan dela Cruz', NULL, 0),
(200, 441, 2, 'Pedro Penduco', NULL, 0),
(201, 444, 1, 'Juan dela Cruz', NULL, 0),
(202, 448, 2, 'Pedro Penduco', NULL, 0),
(203, 449, 1, 'Juan dela Cruz', NULL, 0),
(204, 452, 2, 'Pedro Penduco', NULL, 0),
(205, 453, 1, 'Juan dela Cruz', NULL, 0),
(206, 456, 2, 'Pedro Penduco', NULL, 0),
(207, 457, 1, 'Juan dela Cruz', NULL, 0),
(208, 458, 2, 'Pedro Penduco', NULL, 0),
(209, 459, 1, 'Juan dela Cruz', NULL, 0),
(210, 460, 2, 'Pedro Penduco', NULL, 0),
(211, 462, 1, 'Juan dela Cruz', NULL, 0),
(212, 463, 2, 'Pedro Penduco', NULL, 0),
(213, 464, 1, 'Juan dela Cruz', NULL, 0),
(214, 465, 2, 'Pedro Penduco', NULL, 0),
(215, 466, 1, 'Juan dela Cruz', NULL, 0),
(216, 469, 2, 'Pedro Penduco', NULL, 0),
(217, 472, 1, 'Juan dela Cruz', NULL, 0),
(218, 473, 2, 'Pedro Penduco', NULL, 0),
(219, 475, 1, 'Juan dela Cruz', NULL, 0),
(220, 477, 2, 'Pedro Penduco', NULL, 0),
(221, 478, 1, 'Juan dela Cruz', NULL, 0),
(222, 482, 2, 'Pedro Penduco', NULL, 0),
(223, 483, 1, 'Juan dela Cruz', NULL, 0),
(224, 484, 2, 'Pedro Penduco', NULL, 0),
(225, 490, 1, 'Juan dela Cruz', NULL, 0),
(226, 491, 2, 'Pedro Penduco', NULL, 0),
(227, 493, 1, 'Juan dela Cruz', NULL, 0),
(228, 495, 2, 'Pedro Penduco', NULL, 0),
(229, 497, 1, 'Juan dela Cruz', NULL, 0),
(230, 498, 2, 'Pedro Penduco', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `firefly_watching`
--
-- Creation: Aug 19, 2018 at 06:03 AM
--

CREATE TABLE IF NOT EXISTS `firefly_watching` (
  `cruise_id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `boat_id` int(11) NOT NULL,
  `guide_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`cruise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `girawan_tour`
--
-- Creation: Aug 19, 2018 at 06:13 AM
--

CREATE TABLE IF NOT EXISTS `girawan_tour` (
  `trip_id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `boat_id` int(11) NOT NULL,
  `guide_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`trip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--
-- Creation: Jul 30, 2018 at 10:17 PM
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'administrator'),
(2, 'encoder', 'encoder account'),
(3, 'supervisor', 'supervisory account'),
(4, 'wwf', 'wwf user account'),
(5, 'partner', 'partner account');

-- --------------------------------------------------------

--
-- Table structure for table `island_hopping`
--
-- Creation: Aug 19, 2018 at 06:03 AM
--

CREATE TABLE IF NOT EXISTS `island_hopping` (
  `trip_id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `boat_id` int(11) NOT NULL,
  `guide_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`trip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--
-- Creation: Jul 30, 2018 at 10:17 PM
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `registered_boats`
--
-- Creation: Jul 30, 2018 at 10:17 PM
--

CREATE TABLE IF NOT EXISTS `registered_boats` (
  `boat_id` int(11) NOT NULL AUTO_INCREMENT,
  `boat_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `operator` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_registered` date NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`boat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Jul 30, 2018 at 10:17 PM
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '180.190.51.129', 'DTISDev', '$2y$08$FtsB9q8nHlkljHSFGT1aneCLTlZx61fGlHkA12U7eI7K0CQKc93VS', NULL, 'pj.villarta@gmail.com', NULL, 'SFtVTmNpS-HnZReCqhXmxO456cdbaff03455e508', 1511194434, 'JEdROHNoZQJtDUXIdYtqRu', 1461879649, 1539087040, 1, 'Dev', 'DTIS', 'InfraGrey', NULL),
(2, '180.190.51.129', 'DTIS1', '$2y$08$cgz0tI5BdHmYjjsHJN.0MueOcj0tRDVuIoPjObZZ2.89sYLrWjLLW', NULL, 'jo_cruz2006@yahoo.com', NULL, NULL, NULL, NULL, 1511485511, 1525188704, 1, 'Mayor Jo', 'Cruz', 'Donsol LGU', NULL),
(3, '127.0.0.1', 'DTIS2', '$2y$08$rE28pBa1PzYS77Bd9UsGtOM0fXDu.Lh/fma8EOqXal9QyAy/ROOM.', NULL, 'ted.azares@gmail.com', NULL, NULL, NULL, NULL, 1525187728, NULL, 1, 'Ted', 'Azares', 'Donsol LGU', NULL),
(4, '127.0.0.1', 'Partner1', '$2y$08$00Q9liW5IEbKnKeFexm4h.Rg.ZXCSr4rSWe2YPu5AkZyQtsf0jXgK', NULL, 'gigsterdev9@gmail.com', NULL, NULL, NULL, NULL, 1534615366, 1539015639, 1, 'One', 'Partner', 'InfraGrey', NULL),
(5, '127.0.0.1', 'DTIS3', '$2y$08$Yhe9gsMuhD88CyLK.o/ikOlZou4KMKR./uyBrYPsagDNxj8Olyei6', NULL, 'pj@infragrey.com', NULL, NULL, NULL, NULL, 1534615466, NULL, 1, 'One', 'Supervisor', 'InfraGrey', NULL),
(6, '127.0.0.1', 'Panda', '$2y$08$QFUiJODf4w1HcZ6HWEpgeelkqx2QhBwP9/N8NVv19zCttnlzoAzte', NULL, 'pcvillarta@up.edu.ph', NULL, NULL, NULL, NULL, 1534615829, 1538994190, 1, 'Panda', 'WWF', 'WWF', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--
-- Creation: Jul 30, 2018 at 10:17 PM
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 2),
(4, 4, 5),
(5, 5, 3),
(6, 6, 4);

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--
-- Creation: Aug 19, 2018 at 08:49 PM
--

CREATE TABLE IF NOT EXISTS `visitors` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_visit_year` year(4) NOT NULL COMMENT 'as part of visitor number YYYY-XXXXX',
  `fname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `h_address` text COLLATE utf8_unicode_ci NOT NULL,
  `nationality` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bdate` date NOT NULL,
  `gender` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `civil_status` char(1) COLLATE utf8_unicode_ci NOT NULL COMMENT 'S single, M married, W widowed, O other',
  `mobile_no` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `occupation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `b_address` text COLLATE utf8_unicode_ci NOT NULL,
  `b_contact_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `swimmer` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `diver` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `ice_fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'in case of emergency',
  `ice_address` text COLLATE utf8_unicode_ci NOT NULL,
  `ice_relationship` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ice_contact_nos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 undefined, 1 welcome, 2 conditional entry, 3 total ban',
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`visitor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=113 ;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`visitor_id`, `first_visit_year`, `fname`, `mname`, `lname`, `h_address`, `nationality`, `bdate`, `gender`, `civil_status`, `mobile_no`, `email`, `occupation`, `b_address`, `b_contact_no`, `swimmer`, `diver`, `ice_fullname`, `ice_address`, `ice_relationship`, `ice_contact_nos`, `status`, `remarks`, `trash`, `timestamp`) VALUES
(1, 2018, 'Jurgen', 'X', 'Freund', 'Atherton, QLD 4883Australia', 'German', '1960-01-01', 'M', 'M', '+61439793710', 'freundimages@gmail.com', 'Underwater Photographer', 'Atherton, QLD 4883\r\nAustralia', '+61439793710', 1, 1, 'Stella Chiu Freund', 'Atherton, QLD 4883\r\nAustralia', 'Wife', '+61439793710', 1, 'asdf', 0, '0000-00-00 00:00:00'),
(2, 2018, 'Stella', 'Chiu', 'Freund', 'Atherton, QLD 4883Australia', 'German', '1965-01-01', 'F', 'M', '+61439793710', 'freundimages@gmail.com', 'Producer', 'Atherton, QLD 4883Australia', '+61439793710', 1, 1, 'Jurgen Freund', 'Atherton, QLD 4883Australia', 'Husband', '+61439793710', 1, 'Lorem ipsum dolor consectitur sit amet', 0, '0000-00-00 00:00:00'),
(3, 2018, 'Steven', 'Allan', 'Spielberg', '4 Goldfield Rd.  Honolulu, HI 96815', 'American', '1946-12-18', 'M', 'M', '+1-202-555-0189', 'steven@sahrulselow.cf', 'Filmmaker', '4 Goldfield Rd. \nHonolulu, HI 96815', '+1-202-555-0189', 1, 1, 'Joseph L. Terry', '514 S. Magnolia St. \nOrlando, FL 32806', 'Assistant', '+1-202-555-0189', 1, '', 0, '0000-00-00 00:00:00'),
(4, 2018, 'Davar', 'A', 'Behrooz', 'asdf', 'Afghan', '1980-04-29', 'M', 'S', '5555555', 'me@me.me', 'asdf', 'asdf', 'Behrooz', 1, 1, 'Armi Behrooz', 'asdf', 'Wife', '5555555', 1, '', 0, '0000-00-00 00:00:00'),
(5, 2018, 'Karina', 'Byers', 'Donaldson', '8437 Nulla Street NSW', 'Australian', '1993-10-08', 'F', 'M', '(876) 766-1839', 'metus.sit@mauris.co.uk', 'Employee', '269-953 Molestie Rd. NSW', '(876) 766-1839', 1, 1, 'Pedro Traliva', '8437 Nulla Street NSW', 'husband', '(780) 874-3911', 1, 'massa. Quisque porttitor eros nec tellus. Nunc', 0, '0000-00-00 00:00:00'),
(6, 2018, 'Garth', 'Natalie', 'Mendoza', '566-3819 Scelerisque Rd.', 'Filipino', '1961-07-29', 'M', 'O', '(310) 809-1272', 'ipsum.dolor@vitae.net', 'employee', '175-8900 Hendrerit Road', '(601) 862-9945', 1, 1, 'Hannah E. Watts', 'Ap #137-1728 Consequat Rd.', 'guardian', '(396) 680-8460', 3, 'primis in faucibus orci luctus et', 0, '0000-00-00 00:00:00'),
(7, 2018, 'Silas', 'Alan', 'Holmes', 'P.O. Box 872, 5208 Quis Av.', 'Australian', '1971-04-23', 'F', 'O', '(952) 489-5884', 'magnis.dis@amet.org', 'businessman', '794-7349 Urna. Avenue', '(733) 193-8215', 1, 1, 'Kenyon Joseph', '919-3041 Eu Rd.', 'friend', '(140) 218-6595', 2, 'ut lacus. Nulla tincidunt, neque vitae semper', 0, '0000-00-00 00:00:00'),
(8, 2018, 'Dale', 'Raymond', 'Mathis', '6088 Vestibulum Rd.', 'Filipino', '1995-12-25', 'F', 'O', '(541) 357-3503', 'urna.et@Cras.net', 'businessman', '425-8508 Nam Av.', '(508) 820-4090', 0, 1, 'Cynthia Hayes', '2601 Congue Avenue', 'cousin', '(160) 349-0198', 3, 'ornare lectus justo eu', 0, '0000-00-00 00:00:00'),
(9, 2018, 'Kirsten', 'Elaine', 'Johnston', '1790 Sagittis Av.', 'Filipino', '1999-04-06', 'M', 'S', '(523) 646-6510', 'enim@auctorquis.org', 'other', 'Ap #501-2124 Tempus Rd.', '(900) 532-8138', 0, 0, 'Imelda V. Crosby', '684-4496 Ultrices. St.', 'cousin', '(867) 367-8544', 3, 'dictum eu, placerat eget, venenatis a,', 0, '0000-00-00 00:00:00'),
(10, 2018, 'Daniel', 'Hanna', 'Roberson', 'P.O. Box 965, 1279 Vehicula Av.', 'Indonesian', '1982-06-26', 'F', 'S', '(653) 879-9454', 'consectetuer.cursus@risusaultricies.org', 'other', 'P.O. Box 152, 8237 Euismod Street', '(974) 876-1469', 0, 1, 'Cameran K. Page', '9047 Maecenas St.', 'spouse', '(439) 600-2683', 3, 'lorem,', 0, '0000-00-00 00:00:00'),
(11, 2018, 'Evan', 'Alexa', 'Cummings', '476-3910 Etiam Rd.', 'Thai', '1956-03-27', 'M', 'W', '(958) 646-2987', 'erat.volutpat@nullaIntegerurna.ca', 'employee', '213-3788 Iaculis Avenue', '(592) 224-8214', 1, 0, 'Nita Patrick', '8308 Parturient Rd.', 'spouse', '(125) 984-6447', 0, 'aliquam iaculis,', 0, '0000-00-00 00:00:00'),
(12, 2018, 'Maris', 'Acton', 'Christian', 'Ap #501-1213 Aliquet, Avenue', 'British', '1984-08-27', 'F', 'W', '(538) 927-4935', 'blandit.mattis@suscipitnonummyFusce.net', 'employee', 'P.O. Box 377, 2194 Facilisi. Road', '(209) 762-4417', 0, 0, 'Rahim Mcintosh', '1706 Eu Avenue', 'child', '(255) 460-5195', 1, 'congue, elit sed consequat auctor, nunc nulla vulputate dui,', 0, '0000-00-00 00:00:00'),
(13, 2018, 'Cole', 'Germaine', 'Russo', '166-5816 Arcu. Avenue', 'American', '1980-03-28', 'M', 'M', '(737) 694-3022', 'netus.et.malesuada@massaVestibulumaccumsan.net', 'other', 'Ap #340-8447 Tincidunt Rd.', '(970) 333-6649', 0, 0, 'Yuri Lucas', 'Ap #694-5102 Eu Avenue', 'cousin', '(684) 384-0171', 1, 'sed sem egestas blandit. Nam nulla magna, malesuada vel, convallis', 0, '0000-00-00 00:00:00'),
(14, 2018, 'Aquila', 'Nathan', 'Barker', 'Ap #232-2210 Metus. Av.', 'Indonesian', '1980-01-08', 'F', 'M', '(267) 331-1091', 'magna.sed@a.org', 'businessman', '9591 Aliquet Street', '(534) 857-9832', 1, 0, 'Blair Preston', '9466 Eu, Avenue', 'guardian', '(550) 102-1115', 2, 'natoque penatibus et', 0, '0000-00-00 00:00:00'),
(15, 2018, 'Alexander', 'Tanisha', 'Acosta', 'P.O. Box 984, 3142 Enim Ave', 'Thai', '1987-02-04', 'M', 'M', '(342) 148-9739', 'turpis@urna.net', 'other', 'Ap #172-1238 Magna Rd.', '(152) 474-9634', 0, 0, 'Zia W. Kirkland', '6332 Rutrum, Avenue', 'spouse', '(173) 236-8952', 0, 'elit, pharetra ut, pharetra sed, hendrerit a,', 0, '0000-00-00 00:00:00'),
(16, 2018, 'Guinevere', 'Quynn', 'Morrison', 'P.O. Box 326, 3162 Consectetuer Avenue', 'Australian', '1958-04-22', 'M', 'O', '(139) 335-7020', 'penatibus.et@Curabitur.com', 'other', 'Ap #722-2279 Lacus. Ave', '(277) 244-8040', 1, 0, 'Hu B. Brewer', '9535 Diam Av.', 'child', '(961) 254-0391', 3, 'risus. Donec nibh enim, gravida sit amet,', 0, '0000-00-00 00:00:00'),
(17, 2018, 'Inez', 'Hiram', 'Foley', '3838 Feugiat St.', 'American', '1996-03-17', 'M', 'S', '(405) 397-5691', 'iaculis.nec.eleifend@sociosquad.com', 'other', '1415 Pellentesque Avenue', '(963) 770-3058', 0, 1, 'Suki Chavez', '6182 Egestas. Street', 'guardian', '(894) 798-1463', 2, 'at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat, lectus', 0, '0000-00-00 00:00:00'),
(18, 2018, 'Kevin', 'Tatiana', 'Rodgers', '1623 Ante Road', 'Indonesian', '1995-01-07', 'F', 'M', '(911) 620-2310', 'lorem.luctus@mi.net', 'other', 'P.O. Box 681, 5796 Ullamcorper Avenue', '(108) 337-1225', 0, 0, 'Joel O. Powers', 'Ap #580-6211 Elit, Rd.', 'friend', '(406) 691-8901', 1, 'malesuada', 0, '0000-00-00 00:00:00'),
(19, 2018, 'Phillip', 'Justin', 'Gaines', 'Ap #424-2546 Nunc. Rd.', 'American', '1984-09-12', 'M', 'M', '(845) 893-0286', 'Quisque.libero@vitaeeratVivamus.org', 'businessman', 'P.O. Box 804, 9663 Ligula Ave', '(441) 296-6672', 0, 1, 'Zoe D. Hendrix', '441-5307 Non Road', 'parent', '(672) 874-1818', 1, 'Maecenas ornare egestas ligula. Nullam feugiat placerat', 0, '0000-00-00 00:00:00'),
(20, 2018, 'Eve', 'Ivan', 'Le', 'Ap #136-8729 Arcu. Rd.', 'Australian', '1950-05-03', 'M', 'W', '(354) 651-7614', 'eu@necdiamDuis.co.uk', 'other', 'Ap #122-6017 Leo Rd.', '(796) 739-0272', 0, 0, 'Ulysses Guy', '791-8586 Lobortis Rd.', 'child', '(371) 842-0867', 0, 'odio. Nam interdum enim non nisi. Aenean', 0, '0000-00-00 00:00:00'),
(21, 2018, 'Vincent', 'Rae', 'Briggs', 'P.O. Box 195, 4708 Elit. Avenue', 'Chinese', '2000-11-19', 'M', 'W', '(890) 827-6121', 'elit@Fuscefeugiat.ca', 'other', '228-2539 Proin Street', '(563) 612-2254', 1, 1, 'Rana Patton', '927-6429 Elit Ave', 'parent', '(717) 130-2123', 1, 'lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus euismod', 0, '0000-00-00 00:00:00'),
(22, 2018, 'Armando', 'Brielle', 'Weaver', 'Ap #524-2656 Diam Ave', 'British', '1955-06-05', 'F', 'O', '(600) 354-3778', 'ornare.libero@Nullafacilisi.org', 'businessman', 'Ap #825-8664 Et Av.', '(448) 250-9366', 0, 1, 'Sierra Merritt', 'Ap #389-5679 Ultricies Road', 'parent', '(104) 564-3835', 3, 'dis parturient montes, nascetur ridiculus', 0, '0000-00-00 00:00:00'),
(23, 2018, 'Stacey', 'Theodore', 'Richards', '198-5281 Cursus Street', 'Thai', '1982-08-19', 'F', 'O', '(311) 512-3165', 'penatibus.et@adipiscingelit.net', 'other', '4471 Donec Av.', '(515) 414-5250', 0, 1, 'Blythe Browning', '3166 Volutpat Rd.', 'parent', '(256) 198-0329', 0, 'convallis erat, eget tincidunt dui', 0, '0000-00-00 00:00:00'),
(24, 2018, 'Arsenio', 'Lani', 'Pena', '992-8807 Elit Road', 'American', '1982-01-22', 'F', 'O', '(229) 487-0893', 'erat@metusAeneansed.co.uk', 'employee', '127-5198 Aliquet. St.', '(906) 991-1298', 0, 0, 'Brenden N. Britt', '857-4712 Elit, Rd.', 'cousin', '(520) 589-3706', 3, 'imperdiet ornare. In faucibus. Morbi', 0, '0000-00-00 00:00:00'),
(25, 2018, 'Sophia', 'Reese', 'Ellis', 'P.O. Box 888, 7171 Suspendisse Ave', 'Thai', '1965-01-09', 'M', 'M', '(607) 317-2706', 'sit.amet.metus@magnaDuisdignissim.org', 'businessman', 'Ap #311-1165 Blandit Rd.', '(807) 122-7681', 1, 0, 'Camille Flores', 'P.O. Box 952, 1910 Vitae, Road', 'child', '(656) 116-6397', 2, 'augue malesuada malesuada. Integer', 0, '0000-00-00 00:00:00'),
(26, 2018, 'Carissa', 'Gage', 'Gilliam', '620-6030 Tincidunt Street', 'Thai', '1968-11-30', 'F', 'O', '(636) 737-7086', 'Aliquam@diam.edu', 'employee', '1335 Cras Street', '(831) 898-9553', 0, 1, 'Graiden G. Carr', '8369 Hendrerit. Avenue', 'friend', '(800) 126-9967', 3, 'adipiscing elit. Etiam', 0, '0000-00-00 00:00:00'),
(27, 2018, 'Shana', 'Sierra', 'Larson', '789-6758 Nulla St.', 'British', '1989-07-21', 'M', 'W', '(250) 802-9221', 'gravida.sagittis.Duis@ornarefacilisiseget.ca', 'other', 'P.O. Box 846, 8058 Hymenaeos. Ave', '(438) 914-7832', 1, 1, 'Olympia W. Joyce', 'P.O. Box 972, 7303 Justo Road', 'parent', '(407) 742-8397', 3, 'dictum', 0, '0000-00-00 00:00:00'),
(28, 2018, 'Nelle', 'Serena', 'Holmes', '249-5188 Mauris St.', 'Thai', '1972-01-20', 'F', 'M', '(126) 493-7774', 'massa.Vestibulum.accumsan@Sedpharetra.edu', 'businessman', 'P.O. Box 598, 805 Nec Street', '(116) 246-1427', 0, 0, 'Rahim Cain', 'P.O. Box 486, 9052 Nulla. St.', 'friend', '(164) 128-3406', 1, 'magna. Nam', 0, '0000-00-00 00:00:00'),
(29, 2018, 'Rama', 'Colette', 'Tyson', '473-7901 Dignissim St.', 'Thai', '1977-06-06', 'M', 'M', '(616) 358-3016', 'Aliquam@Aliquam.co.uk', 'businessman', '389-6582 Nibh St.', '(611) 186-4072', 0, 0, 'Karen V. Bradley', '8864 Quis, St.', 'cousin', '(898) 452-8952', 2, 'Nam ligula elit, pretium', 0, '0000-00-00 00:00:00'),
(30, 2018, 'Cheyenne', 'Maisie', 'Riley', 'Ap #865-2008 Elit Street', 'American', '1966-11-27', 'F', 'W', '(312) 367-7373', 'hendrerit@laoreet.org', 'businessman', 'Ap #701-8299 Montes, Rd.', '(887) 491-2374', 0, 1, 'Rowan Payne', 'Ap #101-6090 Cursus Avenue', 'child', '(175) 815-9858', 0, 'ante ipsum primis in faucibus orci luctus et ultrices posuere', 0, '0000-00-00 00:00:00'),
(31, 2018, 'Maisie', 'Maile', 'Coleman', '506-5778 Neque Street', 'Indonesian', '1958-12-31', 'F', 'W', '(606) 303-4548', 'ultrices.Duis@sodalesat.edu', 'businessman', 'Ap #140-5708 Ipsum Ave', '(433) 699-0215', 1, 0, 'Justina Hahn', '566-9850 Non Av.', 'friend', '(363) 807-5240', 3, 'Aliquam tincidunt, nunc', 0, '0000-00-00 00:00:00'),
(32, 2018, 'Marvin', 'Wyoming', 'Sykes', '515-885 Dui St.', 'British', '1973-11-25', 'M', 'M', '(461) 830-3271', 'dolor.Fusce@Proinultrices.org', 'employee', '9088 Dictum Rd.', '(411) 660-5588', 0, 1, 'Camden Z. Rodgers', '554-1112 Elit. Rd.', 'cousin', '(657) 489-0408', 3, 'pharetra, felis eget', 0, '0000-00-00 00:00:00'),
(33, 2018, 'Juliet', 'Alika', 'Good', '709-8646 Nec Road', 'Filipino', '1974-08-23', 'F', 'S', '(611) 841-3535', 'Cum.sociis@aliquamiaculis.net', 'other', '7349 Tincidunt. St.', '(301) 238-7280', 1, 1, 'Hyatt Y. Hunt', 'Ap #386-4034 In St.', 'spouse', '(911) 129-2806', 3, 'vehicula risus. Nulla eget metus', 0, '0000-00-00 00:00:00'),
(34, 2018, 'Yael', 'Macey', 'Hammond', 'P.O. Box 389, 5502 Orci Rd.', 'Chinese', '1976-12-11', 'M', 'O', '(391) 769-1185', 'varius.orci@nibhPhasellusnulla.co.uk', 'other', '292-2458 Scelerisque Ave', '(198) 180-9182', 1, 1, 'Aquila N. Herman', '6863 Orci. Rd.', 'friend', '(139) 352-7721', 3, 'quam. Pellentesque habitant morbi', 0, '0000-00-00 00:00:00'),
(35, 2018, 'Harriet', 'Nina', 'Warner', '9008 Porttitor Rd.', 'Indonesian', '1950-07-03', 'F', 'W', '(356) 255-6110', 'In@fermentumfermentum.org', 'other', 'Ap #475-1291 Et Av.', '(234) 711-9244', 0, 0, 'Ramona Lynn', 'Ap #907-4944 Scelerisque Rd.', 'parent', '(710) 224-8073', 2, 'Vivamus euismod', 0, '0000-00-00 00:00:00'),
(36, 2018, 'Ezra', 'Baker', 'Watkins', '322-1018 Mauris Av.', 'Thai', '1968-12-22', 'M', 'S', '(411) 507-5931', 'diam@Aeneangravidanunc.edu', 'employee', 'Ap #355-7626 Sit Ave', '(676) 250-7294', 1, 0, 'Jeanette Cherry', 'P.O. Box 237, 6577 In Avenue', 'friend', '(113) 362-5667', 3, 'Quisque tincidunt pede ac urna. Ut tincidunt vehicula risus. Nulla', 0, '0000-00-00 00:00:00'),
(37, 2018, 'Nolan', 'Perry', 'Delaney', '524-1234 Fusce St.', 'British', '1976-12-20', 'M', 'S', '(148) 252-6582', 'vitae.risus.Duis@ProindolorNulla.edu', 'other', '423-8812 Nulla. St.', '(695) 314-1977', 1, 1, 'Wyoming Reilly', '366-275 In Avenue', 'guardian', '(136) 487-4442', 0, 'nibh. Phasellus nulla.', 0, '0000-00-00 00:00:00'),
(38, 2018, 'Cheyenne', 'Dante', 'Huber', 'Ap #590-9210 Vel Rd.', 'Indonesian', '1987-08-01', 'F', 'W', '(818) 240-6062', 'amet@dignissim.ca', 'employee', '5832 Enim. Ave', '(467) 894-3284', 1, 1, 'Amity Sutton', '1737 Eget Av.', 'guardian', '(114) 526-3887', 0, 'in, hendrerit consectetuer,', 0, '0000-00-00 00:00:00'),
(39, 2018, 'Hoyt', 'Kylynn', 'Gonzales', 'Ap #699-1865 Dui. Road', 'Chinese', '1988-10-21', 'F', 'O', '(275) 906-8910', 'blandit@sociis.co.uk', 'businessman', 'P.O. Box 970, 8083 Tellus Road', '(245) 900-9154', 0, 1, 'Hakeem Z. Downs', 'Ap #342-3431 Lectus. Rd.', 'friend', '(386) 447-0527', 0, 'dapibus ligula. Aliquam erat', 0, '0000-00-00 00:00:00'),
(40, 2018, 'Hector', 'Alyssa', 'Flynn', 'P.O. Box 642, 2962 Pharetra Road', 'Filipino', '1979-09-21', 'F', 'W', '(304) 846-1390', 'fermentum.risus.at@lacus.edu', 'employee', 'P.O. Box 404, 7936 Auctor, Avenue', '(351) 364-6300', 0, 1, 'Illana H. Norman', 'P.O. Box 164, 3581 Convallis Rd.', 'friend', '(941) 746-2395', 0, 'dapibus ligula. Aliquam', 0, '0000-00-00 00:00:00'),
(41, 2018, 'Chava', 'Asher', 'Whitney', 'P.O. Box 788, 3750 Ut Av.', 'Australian', '1976-10-20', 'M', 'M', '(864) 148-6515', 'egestas@nunc.org', 'other', '9457 Leo, St.', '(218) 469-6739', 1, 0, 'Warren Cummings', '161-6667 Cras Road', 'spouse', '(172) 381-0923', 2, 'Curabitur ut odio vel est', 0, '0000-00-00 00:00:00'),
(42, 2018, 'Penelope', 'Justine', 'Barry', 'Ap #841-6292 Ut Road', 'Australian', '1992-08-02', 'F', 'S', '(959) 779-1346', 'auctor@ligulaAliquamerat.org', 'employee', 'Ap #321-2013 Nunc. Street', '(467) 802-9674', 0, 0, 'Xantha Mcbride', 'P.O. Box 215, 4712 Pharetra, Rd.', 'spouse', '(647) 342-2465', 2, 'vitae sodales nisi magna sed', 0, '0000-00-00 00:00:00'),
(43, 2018, 'Chanda', 'Basil', 'Conway', '298-2634 Magna Av.', 'Chinese', '1956-05-29', 'F', 'S', '(127) 384-6844', 'Cras.interdum.Nunc@eu.ca', 'other', '963-9313 Nullam Rd.', '(558) 150-1063', 1, 1, 'Nadine P. Meadows', '389-7517 Orci Avenue', 'spouse', '(496) 528-9715', 1, 'accumsan laoreet ipsum. Curabitur consequat, lectus sit amet luctus vulputate,', 0, '0000-00-00 00:00:00'),
(44, 2018, 'Macey', 'Alana', 'Payne', 'Ap #753-9821 Adipiscing, Road', 'Filipino', '1994-07-07', 'M', 'S', '(360) 805-8125', 'pharetra.ut.pharetra@maurisrhoncus.com', 'businessman', '963-7306 Dui Rd.', '(415) 770-9174', 0, 1, 'Justin Gardner', '760-4679 Facilisis Road', 'parent', '(750) 909-2137', 2, 'Phasellus dapibus quam quis diam. Pellentesque habitant morbi tristique', 0, '0000-00-00 00:00:00'),
(45, 2018, 'Leslie', 'Mariko', 'Mccullough', '283-9045 Vel, Rd.', 'Indonesian', '2000-09-14', 'M', 'M', '(965) 309-1370', 'pharetra@eusem.edu', 'employee', 'P.O. Box 142, 9270 Metus Street', '(880) 826-6903', 0, 0, 'Graham N. Miller', '3893 Ut, St.', 'child', '(493) 747-5744', 1, 'est, congue', 0, '0000-00-00 00:00:00'),
(46, 2018, 'Winifred', 'Orson', 'Chandler', 'P.O. Box 289, 3349 Turpis Road', 'Filipino', '1959-02-05', 'M', 'O', '(900) 534-9251', 'elit.Etiam@necquamCurabitur.edu', 'businessman', '6089 Non Street', '(871) 893-7116', 1, 0, 'Timothy Horne', '3165 Suspendisse Rd.', 'spouse', '(709) 264-7392', 1, 'dolor vitae dolor. Donec fringilla. Donec feugiat metus sit amet', 0, '0000-00-00 00:00:00'),
(47, 2018, 'Byron', 'Donovan', 'Hampton', 'P.O. Box 986, 234 Lorem St.', 'Indonesian', '1962-07-20', 'M', 'S', '(972) 301-4612', 'fringilla.est.Mauris@Quisque.ca', 'employee', 'Ap #221-8895 Sed Ave', '(837) 741-2305', 0, 0, 'Dakota Bryan', '1716 Nibh. Rd.', 'child', '(277) 274-1869', 3, 'vitae diam. Proin dolor. Nulla semper tellus id nunc', 0, '0000-00-00 00:00:00'),
(48, 2018, 'Porter', 'Hiram', 'Ross', '308-7663 Dictum Rd.', 'Filipino', '1994-06-16', 'M', 'O', '(827) 272-9712', 'ac.libero.nec@Cras.edu', 'employee', '4177 Lectus Rd.', '(794) 551-5095', 0, 0, 'Herman Hopkins', '630-3039 Sed, Rd.', 'child', '(472) 830-8315', 3, 'nonummy ipsum non arcu.', 0, '0000-00-00 00:00:00'),
(49, 2018, 'Karina', 'Addison', 'Gross', '164-995 Arcu. Street', 'British', '1952-04-10', 'M', 'W', '(525) 990-8183', 'fermentum.risus@Quisquetincidunt.org', 'employee', '5577 Adipiscing. Street', '(336) 336-4789', 0, 1, 'Myra Sanchez', '2376 Blandit Av.', 'spouse', '(187) 487-3869', 3, 'non, luctus sit amet,', 0, '0000-00-00 00:00:00'),
(50, 2018, 'Chanda', 'Indira', 'Griffin', '714-3606 Ullamcorper. St.', 'Filipino', '1972-10-30', 'M', 'S', '(673) 394-0954', 'felis.ullamcorper.viverra@orciDonecnibh.net', 'businessman', '324-893 Convallis Avenue', '(180) 982-1621', 0, 1, 'Peter I. Barnett', 'Ap #972-6179 Euismod St.', 'cousin', '(183) 108-0726', 2, 'tellus faucibus leo, in lobortis tellus justo sit amet nulla.', 0, '0000-00-00 00:00:00'),
(51, 2018, 'Tarik', 'Madison', 'Bradshaw', '946-9852 Ut Street', 'Indonesian', '1962-10-28', 'M', 'O', '(455) 916-6728', 'enim.consequat.purus@erosNam.co.uk', 'employee', '551-9656 In Rd.', '(631) 911-5109', 1, 1, 'Holly Rosales', 'Ap #710-7246 Libero Road', 'spouse', '(327) 965-3012', 1, 'dis parturient montes, nascetur ridiculus mus. Proin vel', 0, '0000-00-00 00:00:00'),
(52, 2018, 'Debra', 'Rooney', 'Myers', '5502 Sem Ave', 'Australian', '1990-06-04', 'F', 'W', '(514) 473-0344', 'nulla@sollicitudincommodo.co.uk', 'employee', 'Ap #797-9352 Mauris Ave', '(361) 600-3362', 0, 0, 'Yoko Y. Lyons', 'P.O. Box 453, 2062 Tincidunt Road', 'cousin', '(424) 546-1673', 0, 'nec ante blandit viverra. Donec tempus, lorem', 0, '0000-00-00 00:00:00'),
(53, 2018, 'Cadman', 'Laith', 'Arnold', 'P.O. Box 205, 7214 Tincidunt, Rd.', 'Indonesian', '1981-06-07', 'F', 'M', '(458) 770-2551', 'nibh.Quisque.nonummy@sem.co.uk', 'other', '913-3130 Ullamcorper Av.', '(166) 597-5138', 1, 1, 'Ori S. Coleman', '659 Aliquam, St.', 'cousin', '(278) 145-1470', 2, 'euismod urna. Nullam lobortis quam a', 0, '0000-00-00 00:00:00'),
(54, 2018, 'Marny', 'Georgia', 'Waller', '8845 Ut St.', 'Indonesian', '1999-11-22', 'F', 'S', '(570) 360-4214', 'risus@cursusNunc.edu', 'other', 'Ap #489-6856 Fermentum St.', '(955) 540-8139', 0, 1, 'Nelle G. Sosa', 'Ap #293-562 Vel Street', 'cousin', '(963) 809-3957', 3, 'at lacus. Quisque purus', 0, '0000-00-00 00:00:00'),
(55, 2018, 'Oscar', 'Hashim', 'Burch', 'Ap #385-851 Faucibus Rd.', 'Filipino', '1954-04-30', 'F', 'S', '(172) 758-1410', 'in.tempus@fringillaeuismodenim.co.uk', 'other', 'Ap #573-9290 Orci. Street', '(594) 665-8901', 1, 0, 'Driscoll Q. Leon', '7719 Curabitur St.', 'cousin', '(335) 751-3890', 1, 'vitae dolor. Donec fringilla. Donec feugiat metus sit', 0, '0000-00-00 00:00:00'),
(56, 2018, 'Megan', 'Nissim', 'Benson', 'P.O. Box 205, 6312 Mollis St.', 'Filipino', '1986-09-25', 'M', 'W', '(852) 695-3357', 'Fusce.mi@Suspendisse.ca', 'businessman', '6794 At St.', '(316) 590-5892', 0, 1, 'Abel Byers', 'P.O. Box 379, 7308 Arcu St.', 'child', '(891) 179-4073', 0, 'dolor. Fusce mi lorem, vehicula et, rutrum eu,', 0, '0000-00-00 00:00:00'),
(57, 2018, 'Darrel', 'Mariko', 'Dotson', '885-1314 Gravida Rd.', 'Australian', '1975-06-24', 'M', 'W', '(173) 331-7648', 'sit.amet.massa@malesuadavelvenenatis.edu', 'other', '105-4038 Egestas, St.', '(736) 550-3354', 1, 0, 'Aphrodite Petersen', '317-9161 Ut Street', 'cousin', '(248) 910-8567', 1, 'non, lobortis quis, pede. Suspendisse dui.', 0, '0000-00-00 00:00:00'),
(58, 2018, 'Cara', 'Naida', 'Sexton', '462-5305 Molestie Rd.', 'American', '1955-07-18', 'F', 'O', '(239) 955-1066', 'eu@ac.ca', 'other', 'P.O. Box 966, 3429 Facilisi. St.', '(580) 978-7480', 1, 0, 'Tate Y. Collins', 'Ap #339-7582 Venenatis St.', 'guardian', '(322) 288-3802', 1, 'arcu. Vestibulum ante ipsum primis in faucibus', 0, '0000-00-00 00:00:00'),
(59, 2018, 'Hamish', 'Clare', 'Schroeder', 'P.O. Box 364, 717 Curabitur Rd.', 'Indonesian', '1960-06-09', 'M', 'O', '(592) 209-7777', 'venenatis@Aliquamtinciduntnunc.edu', 'employee', '9008 Ultrices. Avenue', '(823) 911-4095', 0, 1, 'Cameron H. Reeves', 'P.O. Box 755, 6130 Vehicula. Ave', 'parent', '(827) 733-5740', 2, 'hendrerit neque. In ornare sagittis felis.', 0, '0000-00-00 00:00:00'),
(60, 2018, 'Morgan', 'Paula', 'Spence', 'Ap #475-344 Feugiat Avenue', 'Filipino', '1976-02-07', 'M', 'W', '(199) 161-8644', 'mollis.nec.cursus@duiFuscediam.org', 'businessman', '308-5754 Volutpat. Ave', '(160) 306-7683', 0, 1, 'Jenette A. Wong', 'P.O. Box 562, 5740 Malesuada Avenue', 'cousin', '(110) 116-7268', 2, 'feugiat placerat velit. Quisque varius. Nam porttitor scelerisque neque. Nullam', 0, '0000-00-00 00:00:00'),
(61, 2018, 'Wang', 'Keane', 'English', '4316 Vulputate, Road', 'Filipino', '1975-10-11', 'M', 'S', '(573) 889-8748', 'Sed.auctor@laoreet.co.uk', 'employee', 'Ap #374-4042 Vehicula Av.', '(894) 179-4124', 1, 0, 'Alec Dalton', 'P.O. Box 420, 2469 Netus Rd.', 'guardian', '(533) 435-3518', 2, 'Integer eu lacus. Quisque imperdiet, erat nonummy ultricies', 0, '0000-00-00 00:00:00'),
(62, 2018, 'Ali', 'Susan', 'Gould', '8771 Eu, Road', 'Thai', '1981-10-17', 'M', 'W', '(562) 237-8554', 'lobortis.Class.aptent@felisullamcorperviverra.com', 'businessman', 'P.O. Box 717, 7793 Tristique Rd.', '(696) 941-4928', 1, 0, 'Macon Lynn', 'P.O. Box 875, 7932 Suspendisse Av.', 'cousin', '(645) 788-3280', 1, 'vel, vulputate eu, odio. Phasellus at augue', 0, '0000-00-00 00:00:00'),
(63, 2018, 'Cynthia', 'Ivy', 'Jimenez', 'P.O. Box 251, 6628 Mi Rd.', 'Thai', '1996-01-30', 'F', 'O', '(182) 814-3024', 'velit@uteros.org', 'employee', 'Ap #539-7030 Adipiscing St.', '(603) 873-3341', 0, 0, 'Jemima Snyder', '3952 Quisque Road', 'cousin', '(477) 984-9578', 0, 'cursus, diam at pretium aliquet,', 0, '0000-00-00 00:00:00'),
(64, 2018, 'Risa', 'Palmer', 'Dejesus', '4496 Libero. St.', 'American', '1973-02-07', 'M', 'O', '(847) 421-2007', 'ante@enimsit.ca', 'other', '221-2458 Nec Road', '(706) 216-1888', 0, 1, 'Deirdre D. Castillo', 'P.O. Box 103, 9460 Vestibulum Rd.', 'parent', '(818) 413-8967', 3, 'sapien. Nunc pulvinar arcu et pede. Nunc sed', 0, '0000-00-00 00:00:00'),
(65, 2018, 'Carissa', 'Jaime', 'Cox', 'P.O. Box 602, 5165 Faucibus. Rd.', 'American', '1975-10-02', 'M', 'M', '(125) 143-9739', 'sollicitudin@elit.ca', 'employee', '406-5114 Id St.', '(818) 937-8577', 0, 1, 'Patrick Z. Williamson', '746-8622 In Rd.', 'child', '(291) 718-5496', 0, 'lectus. Nullam suscipit,', 0, '0000-00-00 00:00:00'),
(66, 2018, 'Paloma', 'Brenden', 'Munoz', 'P.O. Box 534, 2416 Ligula Road', 'Thai', '1974-09-12', 'M', 'M', '(841) 147-0686', 'et.malesuada@ante.co.uk', 'employee', 'Ap #964-8892 Ornare Ave', '(770) 284-6430', 0, 0, 'Quail U. Schultz', '5026 Nibh Avenue', 'parent', '(426) 110-7217', 0, 'sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla', 0, '0000-00-00 00:00:00'),
(67, 2018, 'Gil', 'Cherokee', 'Porter', 'Ap #562-315 Elit, Rd.', 'Filipino', '1997-04-18', 'M', 'O', '(185) 181-9834', 'dui.semper@magna.org', 'businessman', '6610 Amet, Ave', '(146) 722-7752', 0, 1, 'Chadwick P. Todd', 'Ap #493-7439 Sed St.', 'guardian', '(578) 860-4293', 2, 'sit amet', 0, '0000-00-00 00:00:00'),
(68, 2018, 'Cailin', 'Hermione', 'Mccullough', 'P.O. Box 632, 5095 Eu St.', 'Chinese', '1990-04-01', 'F', 'M', '(542) 975-6359', 'placerat@loremtristique.co.uk', 'employee', 'Ap #756-718 Quis Avenue', '(381) 467-9301', 0, 0, 'Ifeoma F. Donovan', '3876 Libero. St.', 'friend', '(219) 258-9047', 2, 'lobortis tellus justo sit amet', 0, '0000-00-00 00:00:00'),
(69, 2018, 'Barry', 'Glenna', 'Hendricks', 'P.O. Box 486, 3655 Nunc Street', 'Australian', '1970-05-17', 'F', 'W', '(527) 853-1820', 'lacus.pede.sagittis@sapien.edu', 'employee', '5549 Lectus Street', '(971) 322-8542', 1, 0, 'Uma Slater', 'Ap #808-4772 Duis Rd.', 'guardian', '(684) 852-3064', 0, 'primis in faucibus orci luctus et ultrices', 0, '0000-00-00 00:00:00'),
(70, 2018, 'Medge', 'Davis', 'Mays', 'P.O. Box 305, 9589 Ipsum Rd.', 'American', '1958-05-18', 'F', 'M', '(335) 509-1214', 'ultrices@lectussit.edu', 'employee', 'P.O. Box 135, 7562 Consectetuer Avenue', '(174) 631-0631', 1, 0, 'Bo Guthrie', 'Ap #462-3028 Odio. St.', 'cousin', '(183) 567-1528', 0, 'dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum', 0, '0000-00-00 00:00:00'),
(71, 2018, 'Bert', 'Ahmed', 'Santana', 'Ap #466-5404 At, Rd.', 'British', '1982-12-31', 'M', 'O', '(431) 886-8606', 'scelerisque@faucibus.ca', 'employee', '3147 Purus. Ave', '(934) 827-6638', 1, 1, 'Martin K. Cherry', 'P.O. Box 832, 6771 Sed Street', 'child', '(337) 304-8903', 1, 'ante ipsum primis in faucibus orci luctus et ultrices posuere', 0, '0000-00-00 00:00:00'),
(72, 2018, 'India', 'Hamish', 'Pena', 'Ap #355-2959 Penatibus Rd.', 'British', '1984-11-28', 'M', 'O', '(778) 576-0976', 'arcu.ac@idmagnaet.edu', 'businessman', '5906 Vivamus Road', '(628) 693-9773', 1, 1, 'Ray Gross', '8181 Eget Av.', 'parent', '(110) 169-5400', 1, 'adipiscing elit. Etiam laoreet, libero', 0, '0000-00-00 00:00:00'),
(73, 2018, 'Erasmus', 'Winifred', 'Hodge', 'Ap #458-6976 Congue, Rd.', 'Chinese', '1978-02-13', 'M', 'W', '(409) 159-2175', 'a.feugiat@viverra.net', 'other', '1747 Gravida Ave', '(379) 319-1901', 0, 1, 'Kevin Munoz', '812-2946 Suspendisse Avenue', 'spouse', '(676) 475-4013', 0, 'quis diam luctus lobortis. Class aptent', 0, '0000-00-00 00:00:00'),
(74, 2018, 'Hedley', 'Moses', 'Russo', '921-8874 Sed Avenue', 'Filipino', '1981-07-31', 'M', 'M', '(158) 594-0973', 'magnis.dis@Etiam.net', 'other', '4457 Natoque Rd.', '(381) 202-2688', 1, 1, 'Hu Z. Acevedo', 'Ap #956-6704 Id, St.', 'spouse', '(625) 528-4473', 0, 'Donec fringilla. Donec feugiat', 0, '0000-00-00 00:00:00'),
(75, 2018, 'Winter', 'Nigel', 'Atkinson', 'Ap #945-5540 Enim. Ave', 'Australian', '1993-07-01', 'M', 'W', '(840) 986-3483', 'adipiscing.Mauris@nisl.com', 'other', '157-4826 Felis. St.', '(725) 262-9981', 1, 1, 'Delilah Cook', '363-3096 Ligula. Road', 'spouse', '(795) 849-4447', 2, 'adipiscing, enim mi', 0, '0000-00-00 00:00:00'),
(76, 2018, 'Ezekiel', 'Zelenia', 'Duke', '9104 Eros. Ave', 'Chinese', '1966-03-07', 'M', 'M', '(739) 695-3118', 'orci@nonvestibulumnec.ca', 'employee', '7704 Aliquam St.', '(636) 106-0728', 1, 1, 'Donna Estes', '2565 Tincidunt Street', 'guardian', '(595) 816-2406', 0, 'Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices', 0, '0000-00-00 00:00:00'),
(77, 2018, 'Caldwell', 'Wyatt', 'Hardin', 'P.O. Box 383, 2159 Diam Road', 'American', '1994-03-17', 'M', 'S', '(726) 545-6623', 'semper.tellus.id@eu.org', 'businessman', '4689 Nulla. Rd.', '(350) 258-4330', 0, 1, 'Felix X. Goodwin', 'P.O. Box 199, 4462 Ultrices. Av.', 'friend', '(750) 411-0358', 3, 'in faucibus orci luctus', 0, '0000-00-00 00:00:00'),
(78, 2018, 'Camilla', 'Arthur', 'Bullock', 'Ap #302-5683 Proin Rd.', 'British', '1977-08-05', 'M', 'M', '(748) 550-4795', 'mi.tempor@et.co.uk', 'businessman', 'P.O. Box 128, 5401 Enim St.', '(750) 784-2323', 0, 1, 'Belle G. Walsh', 'Ap #171-9303 Mollis Avenue', 'guardian', '(987) 872-4377', 3, 'accumsan neque et nunc. Quisque ornare tortor at', 0, '0000-00-00 00:00:00'),
(79, 2018, 'Bert', 'Casey', 'Peck', 'P.O. Box 379, 3536 Integer Street', 'Chinese', '1994-03-29', 'M', 'O', '(792) 424-7643', 'Duis.at@fringillamilacinia.net', 'businessman', 'Ap #484-4456 Facilisis Av.', '(954) 344-7182', 1, 1, 'Carlos Castaneda', 'Ap #759-5538 Quisque Road', 'cousin', '(470) 879-2573', 2, 'Curabitur dictum. Phasellus in', 0, '0000-00-00 00:00:00'),
(80, 2018, 'Nayda', 'Destiny', 'Gilmore', 'Ap #398-6792 Egestas Ave', 'American', '1972-07-04', 'F', 'W', '(693) 553-7778', 'pede.blandit@turpisegestas.ca', 'other', '3723 Cum Ave', '(406) 940-9001', 1, 0, 'Chloe Ward', '8723 Ipsum. Street', 'friend', '(654) 999-9149', 3, 'tristique senectus et netus', 0, '0000-00-00 00:00:00'),
(81, 2018, 'Jaden', 'Amena', 'Mcmahon', 'Ap #109-7715 Donec St.', 'British', '1982-04-23', 'F', 'W', '(765) 336-6475', 'ornare.libero@neceuismod.co.uk', 'businessman', 'Ap #439-9780 Lorem Street', '(269) 230-4543', 1, 0, 'Mary W. Bailey', 'P.O. Box 572, 8761 Ullamcorper. Rd.', 'guardian', '(116) 606-8167', 1, 'dolor vitae dolor. Donec fringilla. Donec', 0, '0000-00-00 00:00:00'),
(82, 2018, 'Lee', 'Genevieve', 'Best', 'P.O. Box 863, 3468 Augue Av.', 'Australian', '1984-09-09', 'F', 'O', '(262) 320-4317', 'iaculis@ipsumdolorsit.com', 'businessman', '7725 Malesuada. Av.', '(940) 411-4001', 0, 1, 'Sigourney L. Adkins', 'P.O. Box 896, 1023 Ac Rd.', 'parent', '(204) 100-5102', 1, 'Cras eu tellus eu augue', 0, '0000-00-00 00:00:00'),
(83, 2018, 'Jacob', 'Pamela', 'Mitchell', '1344 Malesuada Rd.', 'British', '1953-01-29', 'M', 'W', '(188) 284-3764', 'ridiculus.mus.Donec@Nulla.com', 'businessman', 'P.O. Box 246, 2363 Sapien, Street', '(608) 422-3029', 1, 1, 'Charde Hunt', 'Ap #678-9096 Neque Rd.', 'parent', '(133) 103-3865', 2, 'Aenean', 0, '0000-00-00 00:00:00'),
(84, 2018, 'Angelica', 'Kimberley', 'Caldwell', '291-7861 Aliquam St.', 'Thai', '1983-08-03', 'M', 'W', '(410) 959-4776', 'leo@Vestibulumaccumsanneque.org', 'other', '982-3341 Enim Rd.', '(299) 805-2425', 0, 0, 'Serena R. Hines', 'Ap #800-2792 Tempus Street', 'guardian', '(600) 601-4145', 0, 'eleifend vitae, erat. Vivamus nisi. Mauris nulla. Integer', 0, '0000-00-00 00:00:00'),
(85, 2018, 'Yoko', 'Jorden', 'Caldwell', '716-1977 Enim Rd.', 'Chinese', '1957-02-23', 'F', 'O', '(812) 991-2836', 'dui@atliberoMorbi.co.uk', 'other', '1104 Dignissim. Road', '(934) 435-3432', 1, 0, 'Frances Byrd', 'P.O. Box 246, 5257 Tristique Av.', 'cousin', '(211) 862-9672', 3, 'vulputate, lacus. Cras', 0, '0000-00-00 00:00:00'),
(86, 2018, 'Elliott', 'Hayfa', 'Ayala', 'Ap #670-1191 Magna. Street', 'Australian', '1959-12-12', 'F', 'M', '(407) 360-1440', 'rutrum.non.hendrerit@sociosquad.org', 'other', 'P.O. Box 735, 3390 Habitant Rd.', '(263) 960-8877', 1, 1, 'Cody Keith', 'P.O. Box 489, 1100 Dolor, Rd.', 'cousin', '(572) 836-1529', 1, 'elit, pretium et, rutrum non, hendrerit id, ante. Nunc', 0, '0000-00-00 00:00:00'),
(87, 2018, 'Uma', 'Quincy', 'Marshall', 'Ap #527-6399 Sem Road', 'British', '1993-12-25', 'F', 'W', '(268) 822-1452', 'egestas@rutrumurna.com', 'other', '3879 Integer Rd.', '(571) 800-3803', 0, 1, 'Jennifer Simon', '367 Tellus, Road', 'cousin', '(580) 314-8608', 0, 'eu nulla at', 0, '0000-00-00 00:00:00'),
(88, 2018, 'Holly', 'Clayton', 'Mcmahon', '620-2457 Porttitor Rd.', 'Thai', '1989-02-10', 'M', 'S', '(547) 341-2409', 'posuere.cubilia@sit.co.uk', 'businessman', 'P.O. Box 760, 1692 Curabitur Ave', '(500) 142-7129', 0, 0, 'Hedwig Mcfarland', '557-2772 Enim. Av.', 'cousin', '(337) 223-2807', 3, 'volutpat', 0, '0000-00-00 00:00:00'),
(89, 2018, 'Debra', 'Zeph', 'Glenn', '3054 Bibendum. Ave', 'Filipino', '1993-06-08', 'M', 'W', '(750) 335-8600', 'nunc@vitaemaurissit.edu', 'businessman', '543 Enim. Street', '(844) 223-1394', 1, 1, 'Kai Clements', 'P.O. Box 531, 7374 Enim. Ave', 'guardian', '(815) 961-0721', 2, 'pharetra ut, pharetra sed, hendrerit a, arcu.', 0, '0000-00-00 00:00:00'),
(90, 2018, 'Desirae', 'Emi', 'Johnson', '308-8972 Ante Avenue', 'American', '2000-05-30', 'M', 'M', '(415) 259-4138', 'Donec@vulputate.ca', 'employee', '4474 Nulla Avenue', '(149) 433-9413', 0, 0, 'Ignatius Salinas', 'P.O. Box 956, 6370 Risus. Avenue', 'guardian', '(996) 707-4820', 3, 'vestibulum lorem,', 0, '0000-00-00 00:00:00'),
(91, 2018, 'Kay', 'Marah', 'Dillon', 'P.O. Box 296, 8459 Pellentesque Road', 'Australian', '1995-04-01', 'M', 'S', '(157) 720-8242', 'primis@pedeacurna.org', 'employee', '6509 Elementum, Av.', '(175) 764-5345', 0, 1, 'Reed E. Reynolds', 'P.O. Box 406, 5911 Eleifend Rd.', 'friend', '(392) 694-9162', 1, 'congue turpis. In condimentum. Donec', 0, '0000-00-00 00:00:00'),
(92, 2018, 'Felix', 'Shafira', 'Clark', 'P.O. Box 538, 5129 Tristique Street', 'Filipino', '1982-08-11', 'F', 'O', '(103) 930-5638', 'pellentesque.a.facilisis@euismodurnaNullam.org', 'employee', 'P.O. Box 875, 2808 Nunc Road', '(731) 915-1677', 1, 1, 'Emily C. Dunn', '3765 Auctor Street', 'parent', '(847) 942-1443', 3, 'eros nec tellus. Nunc', 0, '0000-00-00 00:00:00'),
(93, 2018, 'Reese', 'Kasper', 'King', 'P.O. Box 253, 4336 Vitae Av.', 'Chinese', '1983-06-14', 'F', 'S', '(387) 686-6669', 'eget.tincidunt.dui@molestiesodales.co.uk', 'other', 'Ap #388-5707 Donec Rd.', '(645) 262-2272', 0, 1, 'Malachi X. Baxter', 'P.O. Box 430, 4896 Rutrum Avenue', 'guardian', '(314) 318-5290', 3, 'Etiam ligula tortor, dictum eu, placerat eget,', 0, '0000-00-00 00:00:00'),
(94, 2018, 'Cara', 'Sage', 'Rogers', '274-8230 Facilisi. St.', 'Australian', '1958-10-12', 'M', 'S', '(321) 381-0885', 'sit.amet.lorem@egestashendrerit.edu', 'businessman', '423-2118 Quisque Rd.', '(704) 233-1130', 0, 1, 'Deborah Anderson', 'Ap #507-6836 Enim St.', 'guardian', '(426) 161-0641', 1, 'auctor ullamcorper, nisl arcu iaculis', 0, '0000-00-00 00:00:00'),
(95, 2018, 'Arden', 'Daquan', 'Lindsey', 'Ap #674-1058 Dapibus St.', 'Indonesian', '1968-01-15', 'M', 'S', '(644) 634-7718', 'Donec.egestas.Aliquam@Sedeunibh.edu', 'employee', 'P.O. Box 122, 7445 Lorem Rd.', '(727) 591-9743', 1, 0, 'Urielle Bowman', '999-4204 Vitae Avenue', 'cousin', '(819) 241-0609', 1, 'vel, faucibus', 0, '0000-00-00 00:00:00'),
(96, 2018, 'Nita', 'Deanna', 'Reilly', '948-2224 Vitae Ave', 'American', '1964-01-30', 'F', 'W', '(115) 110-0780', 'elementum@consequatnecmollis.com', 'other', 'P.O. Box 326, 7727 Curae Av.', '(515) 247-6945', 0, 0, 'Amos V. Wall', 'P.O. Box 870, 8532 Felis Rd.', 'guardian', '(379) 723-7386', 0, 'quam. Curabitur vel lectus. Cum sociis natoque penatibus et magnis', 0, '0000-00-00 00:00:00'),
(97, 2018, 'Talon', 'James', 'Oneal', '706-7318 Phasellus Av.', 'Chinese', '1982-03-08', 'M', 'S', '(713) 929-8934', 'at@Vestibulumaccumsanneque.ca', 'other', 'Ap #103-6632 Lectus Street', '(459) 685-9846', 1, 1, 'Lewis Hall', '8963 Montes, Ave', 'parent', '(535) 853-5534', 2, 'erat nonummy ultricies', 0, '0000-00-00 00:00:00'),
(98, 2018, 'Zelda', 'Chloe', 'Cantrell', '281-7085 Quis St.', 'Australian', '1952-10-31', 'F', 'S', '(599) 869-3864', 'molestie.dapibus.ligula@lectuspedeultrices.edu', 'businessman', '815-2025 Quis, Avenue', '(977) 401-3104', 0, 1, 'Leigh A. Mckenzie', '8160 Et Ave', 'spouse', '(466) 816-5055', 2, 'enim consequat purus. Maecenas libero', 0, '0000-00-00 00:00:00'),
(99, 2018, 'Robert', 'Zorita', 'Calderon', '2561 Pede. Rd.', 'Filipino', '1955-12-29', 'M', 'S', '(976) 803-7533', 'vitae.posuere.at@Phasellus.co.uk', 'employee', '6790 Cursus Road', '(431) 314-2194', 1, 0, 'Bertha H. Johnson', 'P.O. Box 225, 993 Lobortis Ave', 'parent', '(155) 276-6864', 0, 'sociis natoque penatibus', 0, '0000-00-00 00:00:00'),
(100, 2018, 'Leo', 'Jackson', 'Tate', '345-9058 Placerat, Av.', 'British', '1975-05-08', 'F', 'W', '(280) 724-6398', 'et.euismod.et@Quisque.co.uk', 'other', 'P.O. Box 331, 9306 Rutrum Rd.', '(434) 420-2124', 0, 0, 'Anjolie U. French', '7526 Et Street', 'child', '(665) 666-4701', 0, 'Donec est mauris, rhoncus', 0, '0000-00-00 00:00:00'),
(101, 2018, 'Chester', 'Tamekah', 'Mercer', 'P.O. Box 525, 3185 At St.', 'Australian', '1968-10-28', 'F', 'O', '(203) 157-7783', 'eleifend@quisturpisvitae.co.uk', 'businessman', 'Ap #522-766 Fusce Road', '(759) 563-3495', 1, 1, 'Martha A. Dillon', 'P.O. Box 683, 3232 Aliquam Rd.', 'friend', '(905) 191-3040', 2, 'tellus sem mollis', 0, '0000-00-00 00:00:00'),
(102, 2018, 'Rae', 'Reed', 'Carney', 'Ap #497-6705 Phasellus St.', 'Australian', '1971-08-17', 'M', 'M', '(710) 429-9586', 'cursus.et@nonantebibendum.org', 'businessman', '1300 Pede Rd.', '(190) 377-3654', 1, 1, 'Mira Fowler', '2195 Donec Av.', 'spouse', '(213) 175-1580', 0, 'rutrum lorem ac risus. Morbi metus. Vivamus euismod urna.', 0, '0000-00-00 00:00:00'),
(103, 2018, 'Francesca', 'Kevyn', 'Craig', '3105 Euismod Ave', 'British', '1979-11-21', 'F', 'S', '(955) 768-1428', 'amet.risus.Donec@dolortempusnon.edu', 'other', '742-5218 Non, Street', '(519) 839-5537', 1, 1, 'Ariel S. Ballard', 'Ap #957-2444 Imperdiet, Rd.', 'cousin', '(129) 180-5195', 3, 'pharetra sed, hendrerit a, arcu. Sed et libero.', 0, '0000-00-00 00:00:00'),
(104, 2018, 'Colt', 'Celeste', 'Robbins', 'P.O. Box 277, 5191 Nec Road', 'British', '1952-10-09', 'F', 'W', '(454) 304-2266', 'auctor.nunc@Quisqueliberolacus.com', 'employee', 'Ap #287-7524 Consequat Av.', '(896) 223-4577', 1, 1, 'Brennan R. Travis', 'Ap #508-2944 Sollicitudin Road', 'spouse', '(756) 763-8088', 0, 'sed tortor.', 0, '0000-00-00 00:00:00'),
(105, 2018, 'Kaitlin', 'Carlos', 'Kirk', '741 Vivamus Rd.', 'American', '1972-06-08', 'M', 'W', '(208) 199-8027', 'ut@Cumsociis.co.uk', 'employee', '126-3443 Iaculis Av.', '(496) 687-1932', 0, 0, 'Lavinia A. Hickman', 'Ap #411-1231 Luctus Street', 'cousin', '(803) 800-6093', 0, 'in consectetuer ipsum nunc id enim. Curabitur massa. Vestibulum accumsan', 0, '0000-00-00 00:00:00'),
(106, 2018, 'Jurgen', 'X', 'Freund', 'ul. Kubusia Puchatka 6 Olsztyn Poland', 'Poles', '1960-01-01', 'M', 'S', '88 847 04370', 'jfreund@example.com', 'Writer', 'ul. Kubusia Puchatka 6 Olsztyn Poland', '88 847 04370', 0, 0, 'Janek R Walczak', 'ul. Kubusia Puchatka 6 Olsztyn Poland', 'wife', '88 847 04370', 1, '', 0, '0000-00-00 00:00:00'),
(107, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, '', 0, '0000-00-00 00:00:00'),
(108, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555 ', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; delete this', 1, '2018-10-08 15:59:14'),
(109, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; but partner doesn''t know that (submitted by partner)', 1, '2018-10-08 19:53:12'),
(110, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; but partner doesn''t know that (submitted by partner)', 1, '2018-10-08 19:53:09'),
(111, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; but partner doesn''t know that (submitted by partner)', 1, '2018-10-08 19:57:54'),
(112, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; but partner doesn''t know that (submitted by partner)', 1, '2018-10-08 20:02:48');

-- --------------------------------------------------------

--
-- Table structure for table `visitors_datamod`
--
-- Creation: Aug 18, 2018 at 05:35 PM
--

CREATE TABLE IF NOT EXISTS `visitors_datamod` (
  `visitor_id` int(11) NOT NULL,
  `first_visit_year` year(4) NOT NULL COMMENT 'as part of visitor number YYYY-XXXXX',
  `fname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `h_address` text COLLATE utf8_unicode_ci NOT NULL,
  `nationality` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bdate` date NOT NULL,
  `gender` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `civil_status` char(1) COLLATE utf8_unicode_ci NOT NULL COMMENT 'S single, M married, W widowed, O other',
  `mobile_no` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `occupation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `b_address` text COLLATE utf8_unicode_ci NOT NULL,
  `b_contact_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `swimmer` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `diver` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `ice_fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'in case of emergency',
  `ice_address` text COLLATE utf8_unicode_ci NOT NULL,
  `ice_relationship` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ice_contact_nos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 undefined, 1 welcome, 2 conditional entry, 3 total ban',
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='temporary data storage prior to supervisor approval';

-- --------------------------------------------------------

--
-- Table structure for table `visitors_viapartners`
--
-- Creation: Oct 08, 2018 at 04:42 PM
--

CREATE TABLE IF NOT EXISTS `visitors_viapartners` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_visit_year` year(4) NOT NULL COMMENT 'as part of visitor number YYYY-XXXXX',
  `fname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `h_address` text COLLATE utf8_unicode_ci NOT NULL,
  `nationality` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bdate` date NOT NULL,
  `gender` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `civil_status` char(1) COLLATE utf8_unicode_ci NOT NULL COMMENT 'S single, M married, W widowed, O other',
  `mobile_no` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `occupation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `b_address` text COLLATE utf8_unicode_ci NOT NULL,
  `b_contact_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `swimmer` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `diver` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `ice_fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'in case of emergency',
  `ice_address` text COLLATE utf8_unicode_ci NOT NULL,
  `ice_relationship` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ice_contact_nos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 undefined, 1 welcome, 2 conditional entry, 3 total ban',
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `checked` tinyint(4) NOT NULL,
  `trash` tinyint(1) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`visitor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `visitors_viapartners`
--

INSERT INTO `visitors_viapartners` (`visitor_id`, `first_visit_year`, `fname`, `mname`, `lname`, `h_address`, `nationality`, `bdate`, `gender`, `civil_status`, `mobile_no`, `email`, `occupation`, `b_address`, `b_contact_no`, `swimmer`, `diver`, `ice_fullname`, `ice_address`, `ice_relationship`, `ice_contact_nos`, `status`, `remarks`, `checked`, `trash`, `timestamp`) VALUES
(1, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; but partner doesn''t know that', 0, 0, '2018-10-08 20:03:36'),
(2, 2018, 'Julio', 'A', 'Villarta', '1 First Street QC Philippines', 'Filipino', '2015-08-15', 'M', 'S', '09175555555', 'juliovillarta@example.com', 'Toddler', '1 First Street QC Philippines', '09175555555', 0, 0, 'PJ VIllarta', '1 First Street QC Philippines', 'father', '09164554417', 1, 'dupe; but partner doesn''t know that', 0, 0, '2018-10-08 20:03:33');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--
-- Creation: Aug 19, 2018 at 06:04 AM
--

CREATE TABLE IF NOT EXISTS `visits` (
  `visit_id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `boarding_pass` char(22) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'system generated alphanumeric ((L/F)((visitor_ID(6))(1/2/3)YYYYMMDDHHMMSS)',
  `or_no` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_signed` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `butanding` tinyint(1) NOT NULL COMMENT 'butanding activity',
  `girawan` tinyint(1) NOT NULL COMMENT 'girawan activity',
  `firefly` tinyint(1) NOT NULL COMMENT 'firefly activity',
  `island_hop` tinyint(1) NOT NULL COMMENT 'island_hop activity',
  `visit_remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`visit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=505 ;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`visit_id`, `visitor_id`, `visit_date`, `boarding_pass`, `or_no`, `form_signed`, `butanding`, `girawan`, `firefly`, `island_hop`, `visit_remarks`, `trash`) VALUES
(1, 1, '2018-04-30', 'F000001220180430133430', NULL, 1, 1, 0, 0, 0, '', 0),
(2, 2, '2018-04-30', 'F000002220180430133430', NULL, 1, 1, 0, 0, 0, '', 0),
(3, 19, '2018-07-06', NULL, NULL, 0, 1, 0, 0, 0, 'auctor velit. Aliquam nisl. Nulla eu neque pellentesque', 0),
(4, 86, '2018-06-12', NULL, NULL, 1, 1, 0, 1, 0, 'nec, euismod in, dolor. Fusce feugiat.', 0),
(5, 54, '2018-08-18', NULL, NULL, 0, 0, 1, 0, 0, 'et, euismod et, commodo at, libero. Morbi accumsan laoreet', 0),
(6, 47, '2018-01-23', NULL, NULL, 0, 1, 1, 1, 1, 'dolor quam, elementum at, egestas a, scelerisque sed,', 0),
(7, 1, '2018-08-18', NULL, NULL, 1, 1, 1, 1, 0, 'neque non quam. Pellentesque habitant morbi tristique senectus et netus', 0),
(8, 83, '2018-06-30', NULL, NULL, 1, 1, 1, 0, 1, 'ac metus vitae velit egestas lacinia.', 0),
(9, 40, '2018-07-10', NULL, NULL, 1, 1, 1, 0, 1, 'nunc, ullamcorper eu, euismod ac, fermentum vel,', 0),
(10, 97, '2018-03-14', NULL, NULL, 1, 0, 1, 1, 1, 'tempor bibendum. Donec felis orci, adipiscing non,', 0),
(11, 38, '2018-03-02', NULL, NULL, 0, 0, 0, 1, 0, 'nulla. In tincidunt congue turpis. In condimentum. Donec', 0),
(12, 4, '2018-04-14', NULL, NULL, 1, 0, 0, 0, 1, 'mi. Aliquam gravida mauris ut', 0),
(13, 69, '2018-04-07', NULL, NULL, 1, 0, 1, 1, 1, 'porttitor vulputate,', 0),
(14, 17, '2018-02-02', NULL, NULL, 1, 0, 1, 0, 1, 'ornare, lectus ante dictum mi, ac mattis velit justo nec', 0),
(15, 102, '2018-06-11', NULL, NULL, 0, 0, 0, 1, 1, 'sed tortor. Integer aliquam adipiscing lacus. Ut', 0),
(16, 33, '2018-02-28', NULL, NULL, 0, 1, 1, 1, 1, 'nisl. Maecenas malesuada fringilla est. Mauris eu', 0),
(17, 101, '2018-02-04', NULL, NULL, 1, 1, 1, 1, 1, 'amet, consectetuer', 0),
(18, 20, '2018-05-06', NULL, NULL, 0, 1, 1, 0, 1, 'tellus. Aenean', 0),
(19, 62, '2018-02-28', NULL, NULL, 1, 0, 0, 0, 1, 'lectus pede, ultrices a, auctor', 0),
(20, 12, '2018-01-09', NULL, NULL, 0, 0, 1, 1, 1, 'malesuada id, erat. Etiam vestibulum massa rutrum magna. Cras convallis', 0),
(21, 38, '2018-06-01', NULL, NULL, 1, 1, 1, 0, 1, 'tristique senectus et netus et malesuada fames ac turpis', 0),
(22, 2, '2018-06-03', NULL, NULL, 0, 0, 0, 1, 0, 'euismod est arcu', 0),
(23, 62, '2018-03-22', NULL, NULL, 1, 0, 0, 0, 0, 'accumsan convallis, ante lectus', 0),
(24, 3, '2018-06-29', NULL, NULL, 1, 0, 0, 1, 1, 'eget, volutpat ornare,', 0),
(25, 43, '2018-06-02', NULL, NULL, 1, 0, 1, 0, 1, 'Donec dignissim magna a tortor. Nunc commodo', 0),
(26, 17, '2018-06-29', NULL, NULL, 0, 0, 1, 0, 1, 'fermentum risus, at fringilla purus', 0),
(27, 78, '2018-01-25', NULL, NULL, 0, 1, 0, 0, 1, 'pharetra, felis eget', 0),
(28, 42, '2018-02-11', NULL, NULL, 0, 0, 0, 0, 0, 'amet, faucibus ut, nulla.', 0),
(29, 46, '2018-04-19', NULL, NULL, 1, 0, 1, 1, 1, 'vitae purus', 0),
(30, 18, '2018-05-18', NULL, NULL, 0, 1, 0, 0, 0, 'blandit. Nam nulla magna, malesuada vel, convallis in,', 0),
(31, 95, '2018-05-22', NULL, NULL, 1, 0, 1, 0, 0, 'auctor quis, tristique ac, eleifend vitae, erat. Vivamus', 0),
(32, 56, '2018-06-29', NULL, NULL, 0, 0, 0, 1, 0, 'varius et, euismod et, commodo at, libero. Morbi accumsan', 0),
(33, 64, '2018-07-31', NULL, NULL, 1, 1, 0, 0, 1, 'dictum sapien. Aenean massa. Integer vitae nibh. Donec est', 0),
(34, 31, '2018-02-15', NULL, NULL, 1, 0, 0, 0, 1, 'a,', 0),
(35, 96, '2018-07-30', NULL, NULL, 1, 1, 1, 1, 1, 'lorem ac risus. Morbi metus. Vivamus euismod', 0),
(36, 75, '2018-08-17', NULL, NULL, 0, 1, 0, 0, 0, 'bibendum ullamcorper.', 0),
(37, 34, '2018-05-29', NULL, NULL, 1, 1, 0, 0, 0, 'nec, eleifend non, dapibus rutrum, justo. Praesent', 0),
(38, 102, '2018-07-20', NULL, NULL, 0, 0, 1, 1, 0, 'aliquam eros turpis', 0),
(39, 66, '2018-04-03', NULL, NULL, 1, 0, 0, 1, 1, 'tincidunt adipiscing. Mauris', 0),
(40, 104, '2018-07-29', NULL, NULL, 0, 1, 0, 1, 0, 'hendrerit id, ante. Nunc mauris', 0),
(41, 104, '2018-01-20', NULL, NULL, 1, 0, 0, 1, 1, 'dapibus ligula. Aliquam erat', 0),
(42, 36, '2018-01-10', NULL, NULL, 1, 1, 1, 1, 0, 'ipsum. Donec sollicitudin adipiscing ligula. Aenean gravida', 0),
(43, 85, '2018-04-01', NULL, NULL, 1, 0, 0, 1, 0, 'luctus felis purus ac tellus. Suspendisse sed dolor. Fusce mi', 0),
(44, 80, '2018-08-04', NULL, NULL, 0, 0, 1, 1, 1, 'varius. Nam porttitor scelerisque', 0),
(45, 96, '2018-01-07', NULL, NULL, 0, 1, 0, 0, 1, 'Sed dictum. Proin eget odio. Aliquam vulputate ullamcorper', 0),
(46, 96, '2018-01-06', NULL, NULL, 1, 1, 1, 1, 0, 'eu arcu. Morbi sit amet', 0),
(47, 91, '2018-02-28', NULL, NULL, 1, 1, 1, 1, 0, 'imperdiet ullamcorper. Duis at lacus.', 0),
(48, 11, '2018-02-19', NULL, NULL, 0, 0, 0, 0, 0, 'felis.', 0),
(49, 39, '2018-01-07', NULL, NULL, 0, 1, 0, 1, 1, 'bibendum. Donec felis orci,', 0),
(50, 37, '2018-01-09', NULL, NULL, 1, 1, 1, 1, 1, 'enim mi tempor', 0),
(51, 48, '2018-07-18', NULL, NULL, 1, 1, 1, 1, 0, 'tellus. Aenean egestas hendrerit neque. In ornare sagittis felis. Donec', 0),
(52, 4, '2018-06-20', NULL, NULL, 0, 1, 1, 0, 1, 'iaculis odio. Nam interdum enim non nisi. Aenean eget metus.', 0),
(53, 16, '2018-02-09', NULL, NULL, 0, 0, 0, 1, 1, 'Nulla tincidunt,', 0),
(54, 67, '2018-07-22', NULL, NULL, 1, 0, 0, 1, 0, 'In lorem. Donec', 0),
(55, 100, '2018-07-25', NULL, NULL, 1, 0, 0, 1, 1, 'eu, euismod ac, fermentum vel, mauris. Integer sem', 0),
(56, 71, '2018-06-05', NULL, NULL, 1, 1, 1, 1, 0, 'dictum', 0),
(57, 105, '2018-07-12', NULL, NULL, 1, 0, 0, 0, 0, 'hendrerit consectetuer, cursus et, magna. Praesent interdum ligula', 0),
(58, 77, '2018-03-19', NULL, NULL, 1, 1, 0, 0, 1, 'cubilia Curae Phasellus ornare.', 0),
(59, 67, '2018-07-08', NULL, NULL, 1, 0, 1, 1, 0, 'Curae Phasellus ornare. Fusce mollis. Duis sit amet', 0),
(60, 89, '2018-01-16', NULL, NULL, 1, 0, 0, 0, 0, 'dis parturient montes, nascetur ridiculus mus. Donec dignissim magna', 0),
(61, 4, '2018-06-11', NULL, NULL, 0, 1, 0, 0, 1, 'lacinia', 0),
(62, 48, '2018-02-12', NULL, NULL, 1, 0, 1, 0, 1, 'ornare,', 0),
(63, 42, '2018-02-01', NULL, NULL, 0, 1, 0, 0, 0, 'Integer sem elit, pharetra ut, pharetra sed, hendrerit', 0),
(64, 86, '2018-07-08', NULL, NULL, 1, 1, 1, 1, 0, 'aliquam', 0),
(65, 36, '2018-03-25', NULL, NULL, 0, 0, 1, 0, 0, 'aliquet diam. Sed diam lorem, auctor', 0),
(66, 97, '2018-02-27', NULL, NULL, 1, 0, 1, 1, 0, 'ornare. Fusce', 0),
(67, 35, '2018-08-06', NULL, NULL, 1, 0, 0, 0, 1, 'velit. Sed malesuada augue ut', 0),
(68, 73, '2018-05-13', NULL, NULL, 1, 1, 0, 0, 0, 'eu lacus. Quisque imperdiet, erat nonummy ultricies', 0),
(69, 74, '2018-05-12', NULL, NULL, 1, 0, 0, 0, 1, 'Duis a mi fringilla', 0),
(70, 43, '2018-05-19', NULL, NULL, 0, 0, 1, 0, 1, 'dictum.', 0),
(71, 78, '2018-01-05', NULL, NULL, 1, 1, 0, 0, 1, 'fringilla cursus purus. Nullam scelerisque neque sed sem', 0),
(72, 9, '2018-05-19', NULL, NULL, 1, 0, 1, 1, 1, 'erat semper rutrum. Fusce dolor quam,', 0),
(73, 23, '2018-08-04', NULL, NULL, 0, 1, 0, 0, 1, 'vestibulum', 0),
(74, 44, '2018-02-26', NULL, NULL, 1, 1, 1, 1, 0, 'arcu. Curabitur ut odio vel est tempor bibendum. Donec', 0),
(75, 76, '2018-05-24', NULL, NULL, 1, 1, 1, 0, 0, 'consectetuer rhoncus. Nullam velit', 0),
(76, 51, '2018-07-28', NULL, NULL, 0, 0, 0, 1, 1, 'nec metus facilisis lorem tristique aliquet. Phasellus fermentum', 0),
(77, 100, '2018-03-28', NULL, NULL, 0, 1, 0, 1, 0, 'non magna.', 0),
(78, 5, '2018-08-04', NULL, NULL, 1, 1, 0, 1, 0, 'ullamcorper eu, euismod ac,', 0),
(79, 87, '2018-02-02', NULL, NULL, 0, 1, 1, 0, 1, 'Pellentesque habitant morbi tristique senectus et', 0),
(80, 83, '2018-07-24', NULL, NULL, 1, 0, 1, 0, 0, 'consectetuer adipiscing elit. Etiam laoreet, libero et tristique pellentesque, tellus', 0),
(81, 14, '2018-04-06', NULL, NULL, 1, 0, 1, 1, 0, 'consequat', 0),
(82, 85, '2018-06-05', NULL, NULL, 0, 1, 1, 1, 1, 'scelerisque, lorem ipsum sodales purus,', 0),
(83, 86, '2018-08-09', NULL, NULL, 0, 1, 1, 0, 1, 'In lorem. Donec elementum, lorem ut', 0),
(84, 39, '2018-04-22', NULL, NULL, 1, 1, 0, 0, 1, 'adipiscing.', 0),
(85, 104, '2018-02-23', NULL, NULL, 1, 0, 0, 1, 0, 'felis', 0),
(86, 100, '2018-05-21', NULL, NULL, 1, 0, 1, 1, 1, 'nec mauris blandit mattis. Cras eget nisi dictum augue', 0),
(87, 93, '2018-07-02', NULL, NULL, 1, 0, 1, 1, 0, 'lectus. Nullam suscipit, est ac facilisis facilisis, magna', 0),
(88, 76, '2018-03-14', NULL, NULL, 1, 1, 0, 1, 0, 'porta elit, a feugiat tellus', 0),
(89, 83, '2018-02-26', NULL, NULL, 0, 1, 0, 1, 1, 'tincidunt adipiscing. Mauris molestie pharetra', 0),
(90, 92, '2018-06-19', NULL, NULL, 1, 1, 1, 0, 1, 'velit eget laoreet posuere, enim nisl elementum purus, accumsan interdum', 0),
(91, 41, '2018-04-28', NULL, NULL, 0, 1, 0, 1, 1, 'lorem fringilla ornare placerat, orci lacus vestibulum lorem, sit', 0),
(92, 69, '2018-01-04', NULL, NULL, 0, 1, 0, 0, 0, 'dis parturient', 0),
(93, 32, '2018-07-09', NULL, NULL, 1, 1, 1, 0, 0, 'ac mattis semper, dui lectus', 0),
(94, 75, '2018-04-06', NULL, NULL, 1, 0, 0, 1, 1, 'Nullam vitae diam. Proin dolor. Nulla semper tellus id nunc', 0),
(95, 57, '2018-07-24', NULL, NULL, 0, 1, 1, 0, 1, 'magna. Suspendisse tristique', 0),
(96, 9, '2018-04-21', NULL, NULL, 0, 0, 0, 0, 0, 'sociis natoque', 0),
(97, 49, '2018-02-25', NULL, NULL, 0, 1, 0, 0, 0, 'et libero. Proin mi. Aliquam gravida mauris ut', 0),
(98, 95, '2018-04-01', NULL, NULL, 0, 1, 0, 0, 1, 'sem semper erat, in consectetuer', 0),
(99, 98, '2018-06-25', NULL, NULL, 0, 1, 0, 0, 0, 'eget mollis lectus pede', 0),
(100, 87, '2018-04-16', NULL, NULL, 1, 0, 1, 1, 0, 'sit amet nulla.', 0),
(101, 58, '2018-06-29', NULL, NULL, 0, 0, 1, 0, 0, 'dolor. Donec fringilla. Donec', 0),
(102, 90, '2018-04-02', NULL, NULL, 1, 1, 1, 1, 1, 'Integer in magna.', 0),
(103, 104, '2018-08-05', NULL, NULL, 0, 1, 1, 1, 1, 'quis diam luctus lobortis. Class aptent taciti', 0),
(104, 77, '2018-05-05', NULL, NULL, 0, 1, 0, 0, 1, 'Quisque ornare tortor', 0),
(105, 59, '2018-03-14', NULL, NULL, 0, 1, 0, 1, 1, 'nisi.', 0),
(106, 36, '2018-08-08', NULL, NULL, 0, 0, 0, 0, 0, 'quis', 0),
(107, 72, '2018-08-08', NULL, NULL, 0, 0, 0, 0, 1, 'neque non quam. Pellentesque habitant', 0),
(108, 92, '2018-06-12', NULL, NULL, 0, 1, 0, 0, 0, 'tincidunt adipiscing. Mauris', 0),
(109, 17, '2018-02-11', NULL, NULL, 1, 0, 0, 0, 1, 'egestas nunc sed libero. Proin sed turpis nec mauris blandit', 0),
(110, 39, '2018-07-10', NULL, NULL, 0, 0, 1, 1, 1, 'enim', 0),
(111, 96, '2018-01-03', NULL, NULL, 0, 1, 0, 1, 0, 'velit. Quisque varius.', 0),
(112, 93, '2018-02-05', NULL, NULL, 0, 0, 1, 0, 0, 'luctus et ultrices posuere cubilia Curae', 0),
(113, 33, '2018-01-03', NULL, NULL, 1, 0, 0, 1, 0, 'sem ut cursus luctus, ipsum leo elementum', 0),
(114, 76, '2018-01-20', NULL, NULL, 1, 0, 0, 1, 0, 'Proin dolor. Nulla semper tellus id', 0),
(115, 33, '2018-06-23', NULL, NULL, 0, 1, 1, 1, 0, 'ligula. Aenean gravida nunc sed pede. Cum', 0),
(116, 67, '2018-07-07', NULL, NULL, 1, 1, 1, 0, 0, 'lorem ac risus. Morbi metus. Vivamus', 0),
(117, 87, '2018-08-11', NULL, NULL, 0, 0, 0, 0, 1, 'vitae odio sagittis', 0),
(118, 74, '2018-02-08', NULL, NULL, 0, 1, 1, 1, 1, 'fames ac turpis egestas. Aliquam fringilla cursus purus.', 0),
(119, 12, '2018-02-14', NULL, NULL, 1, 1, 0, 0, 0, 'Aliquam auctor,', 0),
(120, 37, '2018-07-08', NULL, NULL, 1, 0, 1, 1, 0, 'tincidunt nibh. Phasellus nulla. Integer vulputate,', 0),
(121, 10, '2018-03-12', NULL, NULL, 1, 0, 0, 1, 1, 'non, egestas a,', 0),
(122, 30, '2018-06-29', NULL, NULL, 0, 0, 1, 1, 1, 'Sed', 0),
(123, 1, '2018-07-16', NULL, NULL, 0, 0, 1, 0, 0, 'placerat velit. Quisque varius. Nam porttitor scelerisque neque. Nullam', 0),
(124, 74, '2018-05-18', NULL, NULL, 1, 0, 0, 1, 0, 'tempus non, lacinia', 0),
(125, 21, '2018-02-19', NULL, NULL, 0, 1, 0, 1, 0, 'Etiam bibendum fermentum metus.', 0),
(126, 11, '2018-03-05', NULL, NULL, 0, 0, 1, 1, 0, 'Aenean massa. Integer vitae nibh. Donec', 0),
(127, 42, '2018-06-14', NULL, NULL, 1, 1, 1, 0, 1, 'orci,', 0),
(128, 33, '2018-07-19', NULL, NULL, 1, 1, 1, 0, 0, 'Vivamus nisi. Mauris', 0),
(129, 14, '2018-04-08', NULL, NULL, 0, 0, 1, 0, 0, 'lobortis augue scelerisque', 0),
(130, 78, '2018-07-20', NULL, NULL, 0, 0, 1, 0, 1, 'dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur', 0),
(131, 4, '2018-06-21', NULL, NULL, 0, 0, 1, 0, 1, 'tortor. Integer aliquam adipiscing lacus.', 0),
(132, 36, '2018-04-23', NULL, NULL, 1, 1, 0, 0, 1, 'Mauris nulla. Integer urna. Vivamus molestie dapibus', 0),
(133, 10, '2018-01-10', NULL, NULL, 1, 0, 0, 0, 0, 'Aliquam nec enim. Nunc ut erat. Sed nunc est, mollis', 0),
(134, 5, '2018-06-21', NULL, NULL, 1, 0, 0, 1, 0, 'ut, sem. Nulla interdum.', 0),
(135, 52, '2018-04-27', NULL, NULL, 0, 0, 1, 0, 0, 'Curabitur', 0),
(136, 65, '2018-06-17', NULL, NULL, 0, 0, 0, 0, 0, 'nunc', 0),
(137, 77, '2018-01-22', NULL, NULL, 0, 0, 0, 1, 1, 'Ut sagittis lobortis mauris. Suspendisse', 0),
(138, 23, '2018-01-30', NULL, NULL, 0, 1, 1, 1, 1, 'dictum ultricies ligula. Nullam enim. Sed', 0),
(139, 46, '2018-04-19', NULL, NULL, 0, 0, 0, 1, 1, 'eget, ipsum. Donec sollicitudin adipiscing ligula. Aenean', 0),
(140, 51, '2018-01-18', NULL, NULL, 1, 0, 1, 1, 0, 'suscipit, est ac facilisis facilisis, magna', 0),
(141, 99, '2018-05-05', NULL, NULL, 0, 0, 0, 0, 0, 'posuere, enim nisl elementum purus, accumsan interdum', 0),
(142, 59, '2018-01-26', NULL, NULL, 1, 0, 0, 0, 1, 'euismod urna. Nullam lobortis quam a', 0),
(143, 45, '2018-02-11', NULL, NULL, 0, 1, 0, 1, 1, 'Maecenas malesuada fringilla est. Mauris eu turpis. Nulla aliquet. Proin', 0),
(144, 38, '2018-08-17', NULL, NULL, 1, 0, 0, 0, 1, 'Fusce fermentum fermentum arcu.', 0),
(145, 66, '2018-05-23', NULL, NULL, 0, 0, 1, 0, 1, 'Curae Donec tincidunt. Donec vitae erat vel pede', 0),
(146, 29, '2018-03-09', NULL, NULL, 1, 0, 0, 0, 1, 'elit. Etiam', 0),
(147, 43, '2018-05-06', NULL, NULL, 1, 1, 0, 1, 1, 'euismod urna. Nullam lobortis quam a felis', 0),
(148, 13, '2018-04-25', NULL, NULL, 0, 1, 0, 1, 1, 'massa rutrum magna. Cras convallis convallis dolor.', 0),
(149, 38, '2018-05-21', NULL, NULL, 1, 1, 0, 1, 1, 'vitae velit egestas lacinia. Sed congue, elit sed', 0),
(150, 80, '2018-04-08', NULL, NULL, 1, 1, 1, 0, 1, 'at pede. Cras vulputate velit eu sem. Pellentesque ut', 0),
(151, 92, '2018-07-14', NULL, NULL, 0, 0, 0, 0, 1, 'Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed,', 0),
(152, 77, '2018-07-08', NULL, NULL, 0, 1, 1, 1, 0, 'fringilla, porttitor', 0),
(153, 16, '2018-05-12', NULL, NULL, 1, 0, 1, 1, 0, 'velit. Quisque varius. Nam', 0),
(154, 18, '2018-05-05', NULL, NULL, 1, 0, 1, 1, 1, 'a sollicitudin orci', 0),
(155, 70, '2018-03-03', NULL, NULL, 1, 1, 1, 0, 0, 'facilisis.', 0),
(156, 67, '2018-03-18', NULL, NULL, 1, 0, 1, 0, 0, 'fermentum metus.', 0),
(157, 90, '2018-02-09', NULL, NULL, 1, 1, 1, 1, 1, 'bibendum ullamcorper.', 0),
(158, 76, '2018-01-02', NULL, NULL, 0, 0, 1, 0, 1, 'lacus.', 0),
(159, 36, '2018-06-18', NULL, NULL, 1, 0, 1, 1, 1, 'Vestibulum ante ipsum', 0),
(160, 75, '2018-04-10', NULL, NULL, 0, 0, 0, 1, 0, 'Suspendisse aliquet, sem ut cursus', 0),
(161, 5, '2018-05-23', NULL, NULL, 0, 1, 1, 0, 1, 'a, auctor non, feugiat', 0),
(162, 73, '2018-06-18', NULL, NULL, 0, 1, 1, 1, 0, 'neque sed sem egestas blandit. Nam nulla magna, malesuada', 0),
(163, 88, '2018-03-31', NULL, NULL, 0, 1, 1, 1, 0, 'nec, imperdiet nec, leo. Morbi neque tellus,', 0),
(164, 40, '2018-05-05', NULL, NULL, 1, 0, 1, 1, 1, 'dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat', 0),
(165, 43, '2018-01-28', NULL, NULL, 0, 1, 1, 0, 0, 'ac risus. Morbi metus.', 0),
(166, 103, '2018-05-26', NULL, NULL, 1, 0, 1, 1, 1, 'est arcu ac orci. Ut semper', 0),
(167, 25, '2018-06-07', NULL, NULL, 0, 1, 0, 1, 1, 'amet ante. Vivamus non lorem vitae odio sagittis semper. Nam', 0),
(168, 36, '2018-06-23', NULL, NULL, 0, 1, 1, 0, 1, 'ac metus vitae velit egestas lacinia. Sed congue,', 0),
(169, 39, '2018-06-12', NULL, NULL, 1, 0, 0, 1, 0, 'auctor. Mauris vel turpis. Aliquam adipiscing lobortis risus.', 0),
(170, 52, '2018-07-14', NULL, NULL, 1, 1, 1, 0, 0, 'mollis.', 0),
(171, 52, '2018-03-11', NULL, NULL, 0, 0, 1, 1, 1, 'elit. Curabitur sed tortor. Integer', 0),
(172, 103, '2018-05-19', NULL, NULL, 1, 0, 1, 1, 0, 'Aliquam nisl. Nulla', 0),
(173, 76, '2018-08-18', NULL, NULL, 1, 1, 1, 0, 1, 'mi enim, condimentum eget,', 0),
(174, 66, '2018-01-19', NULL, NULL, 1, 0, 1, 0, 1, 'malesuada. Integer', 0),
(175, 101, '2018-07-14', NULL, NULL, 0, 0, 1, 1, 1, 'neque venenatis lacus. Etiam', 0),
(176, 13, '2018-01-18', NULL, NULL, 0, 0, 0, 1, 1, 'et pede. Nunc', 0),
(177, 26, '2018-05-03', NULL, NULL, 0, 0, 0, 0, 1, 'Suspendisse', 0),
(178, 6, '2018-05-15', NULL, NULL, 1, 1, 0, 1, 1, 'tempor bibendum. Donec felis orci,', 0),
(179, 60, '2018-04-11', NULL, NULL, 0, 0, 0, 0, 0, 'sapien. Nunc pulvinar arcu et', 0),
(180, 72, '2018-04-11', NULL, NULL, 1, 1, 1, 0, 0, 'faucibus. Morbi vehicula. Pellentesque tincidunt tempus risus.', 0),
(181, 97, '2018-07-04', NULL, NULL, 0, 1, 1, 0, 0, 'malesuada vel, venenatis vel,', 0),
(182, 52, '2018-04-24', NULL, NULL, 0, 1, 1, 1, 1, 'non', 0),
(183, 5, '2018-04-20', NULL, NULL, 1, 0, 1, 1, 0, 'nunc risus varius orci, in consequat enim diam vel arcu.', 0),
(184, 31, '2018-06-13', NULL, NULL, 1, 1, 0, 1, 0, 'velit egestas lacinia. Sed congue,', 0),
(185, 98, '2018-06-07', NULL, NULL, 1, 0, 0, 1, 0, 'est arcu ac orci. Ut semper pretium neque. Morbi quis', 0),
(186, 57, '2018-01-27', NULL, NULL, 1, 1, 0, 0, 1, 'mauris a', 0),
(187, 95, '2018-06-12', NULL, NULL, 0, 1, 1, 0, 1, 'In', 0),
(188, 75, '2018-07-07', NULL, NULL, 1, 0, 1, 1, 0, 'Ut tincidunt vehicula risus. Nulla eget metus eu erat semper', 0),
(189, 52, '2018-01-25', NULL, NULL, 0, 0, 0, 1, 1, 'nec, diam. Duis mi enim, condimentum eget, volutpat ornare,', 0),
(190, 56, '2018-08-06', NULL, NULL, 1, 1, 0, 1, 1, 'gravida', 0),
(191, 89, '2018-01-15', NULL, NULL, 1, 0, 1, 1, 0, 'vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque', 0),
(192, 46, '2018-08-07', NULL, NULL, 1, 0, 1, 1, 1, 'sem. Pellentesque', 0),
(193, 97, '2018-06-22', NULL, NULL, 1, 0, 0, 0, 0, 'Aenean massa. Integer vitae nibh.', 0),
(194, 59, '2018-08-02', NULL, NULL, 0, 0, 0, 1, 1, 'dolor. Quisque tincidunt pede ac urna. Ut tincidunt vehicula', 0),
(195, 4, '2018-06-19', NULL, NULL, 1, 0, 1, 1, 1, 'mollis. Duis sit amet diam', 0),
(196, 34, '2018-01-08', NULL, NULL, 1, 0, 1, 0, 0, 'Integer sem elit, pharetra ut, pharetra sed,', 0),
(197, 39, '2018-03-28', NULL, NULL, 0, 1, 0, 1, 1, 'nisl sem, consequat nec, mollis vitae, posuere', 0),
(198, 61, '2018-01-26', NULL, NULL, 1, 0, 0, 1, 1, 'enim, gravida sit amet,', 0),
(199, 19, '2018-06-06', NULL, NULL, 1, 0, 1, 0, 1, 'ligula. Nullam enim. Sed nulla', 0),
(200, 8, '2018-01-19', NULL, NULL, 1, 1, 1, 0, 0, 'ante ipsum primis in', 0),
(201, 88, '2018-08-09', NULL, NULL, 1, 0, 0, 1, 1, 'sagittis semper. Nam tempor diam dictum sapien. Aenean', 0),
(202, 61, '2018-03-16', NULL, NULL, 0, 1, 0, 0, 0, 'massa.', 0),
(203, 77, '2018-06-18', NULL, NULL, 1, 0, 0, 1, 1, 'lacus. Cras interdum. Nunc sollicitudin commodo', 0),
(204, 60, '2018-03-15', NULL, NULL, 1, 1, 0, 0, 0, 'eu neque pellentesque massa', 0),
(205, 76, '2018-04-12', NULL, NULL, 0, 1, 1, 1, 0, 'Aliquam ornare, libero at auctor ullamcorper, nisl arcu', 0),
(206, 41, '2018-01-05', NULL, NULL, 0, 1, 1, 0, 0, 'ac, feugiat non,', 0),
(207, 20, '2018-02-15', NULL, NULL, 0, 1, 0, 1, 1, 'arcu. Vestibulum ut eros non enim commodo hendrerit. Donec', 0),
(208, 47, '2018-06-02', NULL, NULL, 0, 1, 0, 1, 1, 'nisl. Maecenas malesuada fringilla', 0),
(209, 44, '2018-04-13', NULL, NULL, 0, 0, 0, 0, 0, 'at, nisi.', 0),
(210, 43, '2018-05-12', NULL, NULL, 1, 0, 1, 0, 0, 'velit egestas lacinia. Sed congue, elit', 0),
(211, 64, '2018-03-26', NULL, NULL, 0, 0, 0, 1, 0, 'Cum sociis natoque', 0),
(212, 74, '2018-07-26', NULL, NULL, 0, 0, 1, 0, 0, 'purus. Nullam scelerisque neque sed sem egestas', 0),
(213, 22, '2018-02-28', NULL, NULL, 0, 0, 0, 1, 1, 'leo elementum sem, vitae aliquam', 0),
(214, 103, '2018-05-26', NULL, NULL, 1, 1, 1, 1, 0, 'odio. Etiam', 0),
(215, 98, '2018-03-15', NULL, NULL, 1, 0, 1, 1, 0, 'Donec consectetuer mauris id sapien. Cras dolor dolor,', 0),
(216, 91, '2018-04-19', NULL, NULL, 1, 1, 0, 1, 1, 'quam dignissim pharetra. Nam ac nulla.', 0),
(217, 43, '2018-06-24', NULL, NULL, 1, 1, 1, 1, 1, 'placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet,', 0),
(218, 18, '2018-01-29', NULL, NULL, 0, 1, 1, 0, 0, 'sed, facilisis vitae, orci. Phasellus dapibus quam quis diam.', 0),
(219, 84, '2018-05-30', NULL, NULL, 1, 0, 0, 1, 1, 'purus, accumsan interdum libero dui', 0),
(220, 25, '2018-02-15', NULL, NULL, 0, 0, 1, 1, 0, 'In lorem. Donec elementum, lorem ut', 0),
(221, 95, '2018-03-05', NULL, NULL, 0, 0, 0, 1, 1, 'Aliquam', 0),
(222, 9, '2018-03-22', NULL, NULL, 1, 1, 1, 0, 0, 'felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam', 0),
(223, 14, '2018-05-29', NULL, NULL, 0, 1, 0, 0, 0, 'sagittis augue, eu tempor', 0),
(224, 10, '2018-08-08', NULL, NULL, 1, 0, 0, 0, 0, 'eu, euismod ac, fermentum vel, mauris. Integer', 0),
(225, 24, '2018-06-08', NULL, NULL, 0, 1, 1, 1, 1, 'Duis sit amet', 0),
(226, 52, '2018-07-05', NULL, NULL, 1, 1, 0, 0, 0, 'Phasellus dapibus quam quis diam. Pellentesque habitant', 0),
(227, 43, '2018-03-11', NULL, NULL, 0, 0, 1, 1, 1, 'odio. Aliquam vulputate ullamcorper magna.', 0),
(228, 1, '2018-07-21', NULL, NULL, 1, 0, 1, 0, 0, 'conubia nostra,', 0),
(229, 33, '2018-08-06', NULL, NULL, 1, 0, 1, 1, 1, 'ut eros non enim commodo hendrerit. Donec porttitor tellus non', 0),
(230, 64, '2018-06-05', NULL, NULL, 0, 1, 0, 0, 1, 'Suspendisse sagittis. Nullam vitae diam.', 0),
(231, 71, '2018-04-15', NULL, NULL, 1, 0, 0, 0, 0, 'nibh sit', 0),
(232, 36, '2018-05-26', NULL, NULL, 0, 1, 1, 0, 0, 'commodo tincidunt nibh. Phasellus nulla. Integer vulputate, risus', 0),
(233, 47, '2018-03-10', NULL, NULL, 0, 1, 0, 1, 0, 'Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui', 0),
(234, 39, '2018-03-11', NULL, NULL, 0, 0, 1, 1, 0, 'Aliquam ultrices iaculis', 0),
(235, 41, '2018-04-20', NULL, NULL, 0, 1, 1, 0, 1, 'lobortis augue scelerisque mollis. Phasellus libero', 0),
(236, 15, '2018-01-16', NULL, NULL, 1, 0, 0, 1, 1, 'metus eu erat semper rutrum. Fusce dolor quam, elementum', 0),
(237, 14, '2018-04-01', NULL, NULL, 1, 0, 0, 0, 0, 'nulla', 0),
(238, 25, '2018-06-25', NULL, NULL, 0, 0, 0, 1, 1, 'Aliquam rutrum lorem ac risus. Morbi metus.', 0),
(239, 80, '2018-07-02', NULL, NULL, 0, 1, 0, 1, 1, 'nibh. Donec est mauris, rhoncus id, mollis nec, cursus a,', 0),
(240, 71, '2018-03-07', NULL, NULL, 1, 0, 1, 1, 1, 'tincidunt nibh. Phasellus nulla. Integer vulputate, risus a', 0),
(241, 96, '2018-06-11', NULL, NULL, 0, 1, 1, 0, 1, 'convallis erat, eget tincidunt dui augue', 0),
(242, 78, '2018-03-18', NULL, NULL, 0, 1, 0, 1, 0, 'et magnis dis parturient montes, nascetur ridiculus mus. Donec', 0),
(243, 2, '2018-07-21', NULL, NULL, 1, 0, 1, 1, 1, 'facilisis lorem tristique', 0),
(244, 29, '2018-02-04', NULL, NULL, 0, 1, 0, 0, 1, 'Class aptent', 0),
(245, 99, '2018-07-02', NULL, NULL, 1, 1, 0, 0, 0, 'egestas. Duis ac arcu.', 0),
(246, 67, '2018-06-11', NULL, NULL, 0, 1, 0, 0, 1, 'vel, vulputate eu,', 0),
(247, 1, '2018-01-24', NULL, NULL, 0, 0, 0, 0, 1, 'Phasellus', 0),
(248, 84, '2018-03-15', NULL, NULL, 0, 0, 0, 0, 1, 'rhoncus. Nullam velit dui, semper', 0),
(249, 33, '2018-07-19', NULL, NULL, 1, 1, 0, 0, 0, 'turpis egestas. Aliquam fringilla', 0),
(250, 55, '2018-08-08', NULL, NULL, 0, 0, 0, 0, 1, 'eu enim. Etiam imperdiet dictum magna. Ut tincidunt orci', 0),
(251, 1, '2018-06-26', NULL, NULL, 1, 1, 0, 0, 0, 'purus, accumsan interdum', 0),
(252, 42, '2018-06-03', NULL, NULL, 1, 0, 0, 0, 0, 'tellus. Phasellus elit pede, malesuada vel,', 0),
(253, 103, '2018-05-30', NULL, NULL, 1, 0, 1, 1, 1, 'sodales elit', 0),
(254, 80, '2018-01-26', NULL, NULL, 0, 1, 1, 1, 0, 'quam. Pellentesque habitant morbi tristique senectus et netus et', 0),
(255, 3, '2018-04-09', NULL, NULL, 1, 0, 1, 0, 1, 'at pede. Cras vulputate velit eu sem. Pellentesque ut', 0),
(256, 49, '2018-03-15', NULL, NULL, 0, 0, 0, 0, 0, 'metus', 0),
(257, 79, '2018-05-03', NULL, NULL, 1, 0, 0, 0, 0, 'malesuada vel, convallis', 0),
(258, 12, '2018-04-05', NULL, NULL, 1, 1, 0, 1, 0, 'tempor bibendum. Donec felis orci, adipiscing non, luctus sit amet,', 0),
(259, 66, '2018-01-16', NULL, NULL, 0, 0, 0, 1, 0, 'aliquet. Phasellus fermentum convallis ligula. Donec', 0),
(260, 72, '2018-04-25', NULL, NULL, 1, 0, 0, 1, 1, 'conubia', 0),
(261, 4, '2018-03-13', NULL, NULL, 0, 1, 0, 0, 0, 'in,', 0),
(262, 40, '2018-08-03', NULL, NULL, 0, 0, 1, 0, 1, 'orci.', 0),
(263, 102, '2018-06-16', NULL, NULL, 1, 0, 1, 0, 1, 'ipsum. Phasellus vitae mauris sit amet lorem semper', 0),
(264, 55, '2018-06-09', NULL, NULL, 1, 0, 0, 0, 1, 'luctus lobortis. Class aptent taciti sociosqu', 0),
(265, 9, '2018-01-03', NULL, NULL, 1, 1, 0, 0, 1, 'justo. Praesent luctus. Curabitur egestas nunc sed', 0),
(266, 79, '2018-01-08', NULL, NULL, 0, 0, 1, 1, 1, 'aliquet odio. Etiam ligula tortor, dictum eu,', 0),
(267, 58, '2018-07-08', NULL, NULL, 1, 0, 1, 0, 0, 'velit in aliquet lobortis,', 0),
(268, 50, '2018-06-19', NULL, NULL, 0, 0, 1, 1, 1, 'nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed', 0),
(269, 40, '2018-06-23', NULL, NULL, 1, 0, 1, 0, 1, 'habitant morbi tristique senectus et netus et malesuada', 0),
(270, 14, '2018-07-10', NULL, NULL, 0, 0, 1, 1, 0, 'Proin', 0),
(271, 2, '2018-03-30', NULL, NULL, 1, 0, 1, 1, 0, 'odio tristique pharetra. Quisque ac libero nec', 0),
(272, 19, '2018-03-23', NULL, NULL, 0, 0, 1, 0, 0, 'purus. Maecenas libero est,', 0),
(273, 99, '2018-08-17', NULL, NULL, 1, 1, 0, 0, 1, 'et magnis dis parturient montes, nascetur ridiculus mus.', 0),
(274, 73, '2018-01-24', NULL, NULL, 0, 0, 0, 1, 1, 'aliquam arcu. Aliquam ultrices iaculis odio.', 0),
(275, 52, '2018-04-12', NULL, NULL, 1, 1, 0, 1, 1, 'nec mauris blandit mattis. Cras eget nisi dictum', 0),
(276, 1, '2018-06-26', NULL, NULL, 0, 1, 0, 0, 1, 'Sed auctor odio a purus. Duis', 0),
(277, 93, '2018-06-23', NULL, NULL, 1, 1, 0, 1, 1, 'lobortis quis, pede. Suspendisse dui.', 0),
(278, 53, '2018-02-22', NULL, NULL, 1, 0, 0, 0, 0, 'a felis ullamcorper viverra. Maecenas iaculis aliquet diam.', 0),
(279, 71, '2018-01-04', NULL, NULL, 0, 1, 0, 0, 0, 'mauris. Morbi non sapien molestie', 0),
(280, 27, '2018-06-26', NULL, NULL, 0, 1, 1, 0, 1, 'vel turpis. Aliquam adipiscing lobortis risus. In mi pede, nonummy', 0),
(281, 58, '2018-01-29', NULL, NULL, 1, 0, 0, 1, 1, 'tincidunt nibh.', 0),
(282, 60, '2018-04-06', NULL, NULL, 0, 0, 1, 0, 0, 'volutpat ornare,', 0),
(283, 94, '2018-02-04', NULL, NULL, 0, 0, 0, 1, 1, 'laoreet posuere, enim nisl elementum', 0),
(284, 82, '2018-01-30', NULL, NULL, 0, 1, 0, 0, 0, 'et magnis dis parturient montes, nascetur ridiculus', 0),
(285, 99, '2018-07-13', NULL, NULL, 0, 1, 1, 1, 1, 'natoque penatibus et magnis dis parturient montes, nascetur', 0),
(286, 17, '2018-07-02', NULL, NULL, 0, 0, 0, 1, 0, 'Duis at lacus. Quisque purus', 0),
(287, 59, '2018-07-28', NULL, NULL, 0, 0, 0, 0, 0, 'senectus et netus et malesuada fames', 0),
(288, 101, '2018-07-26', NULL, NULL, 1, 0, 0, 0, 1, 'sit amet lorem', 0),
(289, 29, '2018-05-17', NULL, NULL, 1, 1, 1, 0, 1, 'Quisque nonummy ipsum non arcu. Vivamus sit amet risus.', 0),
(290, 7, '2018-06-19', NULL, NULL, 1, 0, 0, 1, 1, 'sed tortor. Integer aliquam adipiscing lacus.', 0),
(291, 46, '2018-06-03', NULL, NULL, 0, 0, 0, 0, 1, 'feugiat tellus lorem eu', 0),
(292, 85, '2018-01-20', NULL, NULL, 0, 1, 0, 1, 0, 'ut erat. Sed nunc est, mollis non,', 0),
(293, 105, '2018-06-09', NULL, NULL, 0, 1, 1, 1, 1, 'Donec dignissim magna', 0),
(294, 44, '2018-06-12', NULL, NULL, 1, 1, 0, 0, 0, 'quis arcu vel quam dignissim', 0),
(295, 9, '2018-01-07', NULL, NULL, 1, 0, 0, 1, 0, 'malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus', 0),
(296, 12, '2018-07-17', NULL, NULL, 1, 0, 0, 0, 1, 'Nunc quis arcu vel quam dignissim pharetra. Nam ac', 0),
(297, 3, '2018-05-23', NULL, NULL, 0, 1, 1, 0, 0, 'tristique senectus et netus et malesuada fames ac turpis', 0),
(298, 104, '2018-02-16', NULL, NULL, 1, 1, 1, 1, 0, 'Morbi neque tellus, imperdiet non, vestibulum nec, euismod in, dolor.', 0),
(299, 62, '2018-02-15', NULL, NULL, 0, 0, 1, 1, 0, 'ante. Nunc mauris', 0),
(300, 94, '2018-06-23', NULL, NULL, 1, 1, 1, 1, 0, 'Ut tincidunt orci', 0),
(301, 30, '2018-07-12', NULL, NULL, 0, 1, 0, 0, 0, 'neque sed sem egestas blandit. Nam', 0),
(302, 43, '2018-02-15', NULL, NULL, 0, 0, 0, 1, 1, 'Aliquam vulputate ullamcorper magna. Sed eu eros.', 0),
(303, 29, '2018-07-31', NULL, NULL, 0, 1, 0, 1, 0, 'cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut,', 0),
(304, 33, '2018-07-12', NULL, NULL, 0, 1, 1, 0, 1, 'nisi nibh', 0),
(305, 74, '2018-07-21', NULL, NULL, 0, 0, 1, 0, 0, 'In ornare sagittis felis.', 0),
(306, 27, '2018-06-02', NULL, NULL, 1, 1, 1, 1, 1, 'Nulla facilisis. Suspendisse commodo tincidunt nibh. Phasellus nulla. Integer vulputate,', 0),
(307, 99, '2018-05-29', NULL, NULL, 1, 1, 0, 0, 0, 'ante. Nunc mauris sapien, cursus', 0),
(308, 8, '2018-05-24', NULL, NULL, 1, 0, 0, 0, 0, 'magna.', 0),
(309, 20, '2018-01-19', NULL, NULL, 1, 0, 1, 0, 0, 'lectus. Cum sociis natoque penatibus et magnis dis', 0),
(310, 49, '2018-03-13', NULL, NULL, 0, 1, 1, 0, 1, 'massa non ante bibendum', 0),
(311, 88, '2018-02-16', NULL, NULL, 1, 0, 0, 0, 0, 'ipsum. Donec sollicitudin adipiscing ligula.', 0),
(312, 59, '2018-01-01', NULL, NULL, 0, 0, 0, 0, 1, 'est, vitae sodales nisi magna sed dui. Fusce', 0),
(313, 13, '2018-08-07', NULL, NULL, 1, 0, 0, 0, 0, 'ullamcorper eu, euismod ac, fermentum vel, mauris.', 0),
(314, 28, '2018-01-02', NULL, NULL, 1, 0, 1, 1, 0, 'sapien. Aenean massa. Integer vitae nibh.', 0),
(315, 87, '2018-07-16', NULL, NULL, 1, 1, 0, 1, 1, 'tristique pellentesque, tellus sem mollis dui,', 0),
(316, 46, '2018-07-24', NULL, NULL, 1, 1, 0, 1, 0, 'Suspendisse aliquet, sem ut cursus luctus, ipsum leo elementum', 0),
(317, 22, '2018-01-09', NULL, NULL, 0, 0, 0, 0, 1, 'tellus non magna. Nam ligula elit, pretium et, rutrum non,', 0),
(318, 55, '2018-04-11', NULL, NULL, 1, 1, 1, 1, 0, 'nisi magna sed dui. Fusce aliquam, enim nec', 0),
(319, 23, '2018-07-15', NULL, NULL, 0, 1, 0, 1, 1, 'erat eget', 0),
(320, 82, '2018-08-13', NULL, NULL, 1, 0, 1, 0, 0, 'neque tellus, imperdiet', 0),
(321, 6, '2018-05-12', NULL, NULL, 0, 0, 1, 0, 1, 'Nullam velit dui, semper et, lacinia vitae, sodales at,', 0),
(322, 22, '2018-03-12', NULL, NULL, 1, 0, 1, 0, 1, 'accumsan sed, facilisis vitae,', 0),
(323, 28, '2018-07-01', NULL, NULL, 1, 0, 1, 1, 1, 'faucibus', 0),
(324, 41, '2018-03-02', NULL, NULL, 0, 1, 1, 0, 0, 'dolor sit amet, consectetuer adipiscing elit. Aliquam auctor,', 0),
(325, 70, '2018-01-22', NULL, NULL, 1, 0, 1, 0, 0, 'nec tempus', 0),
(326, 8, '2018-04-28', NULL, NULL, 1, 1, 1, 0, 0, 'felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris', 0),
(327, 80, '2018-06-26', NULL, NULL, 1, 1, 0, 1, 0, 'libero et tristique pellentesque, tellus sem', 0),
(328, 18, '2018-01-01', NULL, NULL, 1, 0, 0, 1, 0, 'in, cursus et, eros. Proin ultrices.', 0),
(329, 63, '2018-06-08', NULL, NULL, 1, 0, 1, 1, 0, 'metus. In lorem. Donec elementum,', 0),
(330, 87, '2018-03-23', NULL, NULL, 1, 0, 1, 0, 0, 'Quisque tincidunt pede ac urna. Ut tincidunt', 0),
(331, 4, '2018-05-26', NULL, NULL, 0, 0, 1, 1, 0, 'in sodales elit erat vitae risus. Duis a', 0),
(332, 20, '2018-05-18', NULL, NULL, 1, 0, 1, 1, 1, 'sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem', 0),
(333, 9, '2018-05-10', NULL, NULL, 1, 0, 0, 1, 1, 'Donec tempor, est ac mattis semper, dui lectus rutrum urna,', 0),
(334, 58, '2018-01-14', NULL, NULL, 0, 1, 1, 1, 1, 'a', 0),
(335, 33, '2018-05-19', NULL, NULL, 0, 1, 1, 0, 0, 'Donec felis orci,', 0),
(336, 75, '2018-05-24', NULL, NULL, 0, 1, 1, 0, 0, 'commodo', 0),
(337, 42, '2018-06-27', NULL, NULL, 0, 0, 0, 1, 1, 'feugiat. Lorem ipsum dolor sit', 0),
(338, 54, '2018-02-24', NULL, NULL, 0, 1, 0, 0, 0, 'nec', 0),
(339, 31, '2018-04-29', NULL, NULL, 0, 1, 1, 1, 1, 'magna nec quam. Curabitur vel lectus. Cum', 0),
(340, 37, '2018-08-02', NULL, NULL, 0, 0, 1, 0, 1, 'fringilla', 0),
(341, 10, '2018-04-18', NULL, NULL, 0, 1, 0, 0, 1, 'Nam tempor diam dictum sapien. Aenean', 0),
(342, 12, '2018-01-21', NULL, NULL, 1, 0, 1, 1, 0, 'Nam porttitor scelerisque', 0),
(343, 103, '2018-04-03', NULL, NULL, 1, 1, 1, 0, 1, 'rutrum non, hendrerit id, ante. Nunc mauris sapien, cursus', 0),
(344, 84, '2018-06-01', NULL, NULL, 1, 0, 1, 1, 1, 'mauris a nunc. In', 0),
(345, 69, '2018-04-06', NULL, NULL, 1, 0, 1, 0, 1, 'Duis sit amet', 0),
(346, 62, '2018-07-26', NULL, NULL, 1, 1, 0, 0, 0, 'ante.', 0),
(347, 56, '2018-04-13', NULL, NULL, 0, 1, 1, 1, 0, 'vitae, aliquet nec, imperdiet nec, leo. Morbi neque', 0),
(348, 23, '2018-03-12', NULL, NULL, 0, 0, 1, 0, 0, 'erat. Vivamus nisi. Mauris nulla.', 0),
(349, 85, '2018-01-23', NULL, NULL, 1, 1, 1, 1, 0, 'est. Nunc laoreet lectus quis', 0),
(350, 62, '2018-08-11', NULL, NULL, 1, 0, 1, 0, 0, 'tincidunt congue turpis. In condimentum. Donec', 0),
(351, 102, '2018-01-19', NULL, NULL, 0, 0, 0, 1, 0, 'fermentum vel, mauris. Integer sem elit, pharetra', 0),
(352, 67, '2018-04-12', NULL, NULL, 0, 0, 0, 0, 1, 'Sed', 0),
(353, 101, '2018-08-10', NULL, NULL, 0, 1, 1, 0, 0, 'metus vitae velit egestas lacinia. Sed congue, elit sed', 0),
(354, 11, '2018-01-20', NULL, NULL, 1, 0, 1, 0, 0, 'varius ultrices, mauris ipsum porta elit, a', 0),
(355, 33, '2018-07-23', NULL, NULL, 1, 0, 0, 1, 1, 'non justo. Proin', 0),
(356, 47, '2018-05-24', NULL, NULL, 0, 0, 1, 1, 0, 'sit amet nulla. Donec non justo. Proin non', 0),
(357, 5, '2018-04-08', NULL, NULL, 1, 0, 0, 0, 1, 'at pede.', 0),
(358, 21, '2018-03-13', NULL, NULL, 1, 0, 0, 0, 1, 'at', 0),
(359, 37, '2018-05-23', NULL, NULL, 1, 0, 0, 0, 0, 'vulputate, lacus. Cras interdum. Nunc sollicitudin commodo ipsum. Suspendisse', 0),
(360, 105, '2018-08-10', NULL, NULL, 0, 1, 1, 1, 0, 'egestas. Fusce aliquet magna a neque.', 0),
(361, 1, '2018-04-19', NULL, NULL, 0, 1, 0, 1, 0, 'dui, in sodales elit erat', 0),
(362, 75, '2018-07-28', NULL, NULL, 1, 0, 0, 1, 1, 'aliquam', 0),
(363, 104, '2018-03-12', NULL, NULL, 1, 1, 1, 1, 1, 'pede, malesuada vel, venenatis vel, faucibus id, libero. Donec', 0),
(364, 101, '2018-07-01', NULL, NULL, 1, 1, 0, 1, 1, 'vulputate mauris sagittis placerat. Cras dictum', 0),
(365, 49, '2018-06-21', NULL, NULL, 0, 0, 0, 0, 1, 'nec tellus. Nunc', 0),
(366, 9, '2018-01-31', NULL, NULL, 0, 1, 1, 0, 1, 'in lobortis', 0),
(367, 72, '2018-08-18', NULL, NULL, 1, 1, 0, 1, 0, 'suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum', 0),
(368, 100, '2018-05-18', NULL, NULL, 1, 1, 0, 1, 1, 'Morbi non', 0),
(369, 57, '2018-01-27', NULL, NULL, 0, 0, 0, 1, 0, 'facilisis.', 0),
(370, 68, '2018-07-15', NULL, NULL, 1, 1, 1, 1, 0, 'dictum. Proin eget odio. Aliquam vulputate ullamcorper', 0),
(371, 57, '2018-08-15', NULL, NULL, 0, 0, 1, 0, 0, 'orci sem', 0),
(372, 38, '2018-02-27', NULL, NULL, 1, 1, 0, 0, 0, 'lorem, luctus ut, pellentesque eget, dictum', 0),
(373, 46, '2018-05-11', NULL, NULL, 0, 0, 1, 1, 0, 'sem semper erat,', 0),
(374, 82, '2018-08-18', NULL, NULL, 1, 0, 1, 0, 0, 'porttitor scelerisque neque.', 0),
(375, 90, '2018-06-21', NULL, NULL, 0, 0, 0, 1, 0, 'nisi dictum augue malesuada malesuada. Integer id magna et ipsum', 0),
(376, 68, '2018-07-21', NULL, NULL, 1, 0, 1, 0, 0, 'at', 0),
(377, 13, '2018-06-14', NULL, NULL, 0, 1, 0, 1, 0, 'egestas hendrerit neque. In ornare', 0),
(378, 44, '2018-01-23', NULL, NULL, 1, 1, 0, 0, 1, 'id ante dictum cursus.', 0),
(379, 26, '2018-07-19', NULL, NULL, 0, 0, 1, 1, 1, 'purus ac tellus. Suspendisse sed dolor. Fusce mi lorem,', 0),
(380, 73, '2018-01-07', NULL, NULL, 1, 1, 0, 1, 1, 'Suspendisse eleifend. Cras sed', 0),
(381, 105, '2018-04-21', NULL, NULL, 0, 0, 1, 1, 1, 'mi pede, nonummy ut, molestie in,', 0),
(382, 100, '2018-08-14', NULL, NULL, 0, 0, 0, 1, 1, 'natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 0),
(383, 65, '2018-07-29', NULL, NULL, 0, 0, 0, 1, 0, 'mauris blandit mattis. Cras eget nisi dictum augue', 0),
(384, 76, '2018-06-01', NULL, NULL, 1, 0, 1, 1, 0, 'tellus eu augue porttitor interdum. Sed', 0),
(385, 69, '2018-05-27', NULL, NULL, 0, 1, 1, 0, 1, 'Mauris nulla. Integer urna. Vivamus molestie dapibus ligula. Aliquam', 0),
(386, 84, '2018-06-13', NULL, NULL, 1, 0, 0, 1, 1, 'Sed neque. Sed eget lacus. Mauris non dui nec urna', 0),
(387, 5, '2018-08-03', NULL, NULL, 0, 1, 0, 0, 0, 'euismod ac, fermentum', 0),
(388, 63, '2018-03-08', NULL, NULL, 1, 0, 1, 0, 0, 'quis diam', 0),
(389, 77, '2018-05-20', NULL, NULL, 0, 0, 0, 1, 1, 'massa. Integer vitae nibh. Donec est', 0),
(390, 101, '2018-04-03', NULL, NULL, 0, 0, 0, 0, 1, 'felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum.', 0),
(391, 73, '2018-01-21', NULL, NULL, 1, 0, 0, 1, 1, 'Cum sociis natoque penatibus et', 0),
(392, 94, '2018-05-12', NULL, NULL, 0, 0, 1, 1, 1, 'ac tellus. Suspendisse sed dolor. Fusce mi lorem,', 0),
(393, 28, '2018-05-05', NULL, NULL, 1, 1, 1, 0, 1, 'conubia nostra, per inceptos hymenaeos. Mauris ut quam vel', 0),
(394, 93, '2018-04-27', NULL, NULL, 0, 0, 0, 1, 0, 'tellus lorem', 0),
(395, 76, '2018-08-06', NULL, NULL, 1, 0, 0, 1, 1, 'Morbi accumsan laoreet ipsum. Curabitur', 0),
(396, 99, '2018-03-15', NULL, NULL, 0, 0, 1, 1, 0, 'odio.', 0),
(397, 28, '2018-01-24', NULL, NULL, 0, 1, 1, 1, 0, 'ac orci. Ut semper pretium', 0),
(398, 37, '2018-05-30', NULL, NULL, 1, 1, 0, 1, 0, 'turpis', 0),
(399, 37, '2018-08-13', NULL, NULL, 0, 0, 0, 1, 0, 'et, commodo at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat,', 0),
(400, 26, '2018-06-17', NULL, NULL, 0, 0, 0, 0, 0, 'fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum.', 0),
(401, 44, '2018-06-10', NULL, NULL, 1, 1, 0, 1, 1, 'tortor. Nunc commodo auctor velit. Aliquam nisl. Nulla', 0),
(402, 27, '2018-06-05', NULL, NULL, 1, 0, 0, 0, 0, 'lorem, vehicula et, rutrum eu, ultrices sit amet, risus. Donec', 0),
(403, 14, '2018-03-02', NULL, NULL, 1, 0, 1, 1, 0, 'dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis', 0),
(404, 4, '2018-02-19', NULL, NULL, 1, 0, 0, 1, 1, 'dapibus ligula. Aliquam erat volutpat. Nulla', 0),
(405, 78, '2018-03-02', NULL, NULL, 0, 0, 0, 1, 1, 'nulla ante, iaculis nec, eleifend non, dapibus rutrum,', 0),
(406, 47, '2018-06-20', NULL, NULL, 1, 1, 0, 0, 0, 'Donec', 0),
(407, 85, '2018-03-20', NULL, NULL, 0, 1, 0, 0, 1, 'In scelerisque scelerisque', 0),
(408, 10, '2018-07-09', NULL, NULL, 1, 1, 1, 0, 1, 'vulputate dui, nec tempus mauris', 0),
(409, 51, '2018-07-15', NULL, NULL, 0, 0, 0, 1, 0, 'egestas hendrerit neque. In', 0),
(410, 56, '2018-07-27', NULL, NULL, 0, 0, 1, 0, 0, 'lectus justo eu arcu. Morbi sit amet massa. Quisque', 0),
(411, 34, '2018-03-21', NULL, NULL, 0, 1, 0, 1, 0, 'vitae, erat. Vivamus nisi. Mauris nulla. Integer urna.', 0),
(412, 90, '2018-04-29', NULL, NULL, 0, 0, 0, 0, 1, 'natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 0),
(413, 21, '2018-03-09', NULL, NULL, 0, 0, 0, 0, 0, 'nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim.', 0),
(414, 18, '2018-04-28', NULL, NULL, 1, 0, 0, 1, 0, 'consequat dolor vitae dolor. Donec fringilla.', 0),
(415, 85, '2018-01-27', NULL, NULL, 1, 1, 1, 0, 1, 'elit, dictum eu, eleifend nec, malesuada', 0),
(416, 52, '2018-05-01', NULL, NULL, 1, 1, 1, 0, 0, 'tempus non, lacinia at, iaculis quis, pede.', 0),
(417, 50, '2018-06-13', NULL, NULL, 1, 1, 1, 1, 0, 'Nunc quis arcu vel quam dignissim pharetra.', 0),
(418, 27, '2018-05-29', NULL, NULL, 0, 0, 1, 0, 0, 'tincidunt orci quis lectus. Nullam suscipit, est ac facilisis facilisis,', 0),
(419, 80, '2018-03-30', NULL, NULL, 1, 0, 1, 1, 1, 'eros turpis non enim.', 0),
(420, 88, '2018-07-22', NULL, NULL, 0, 1, 1, 0, 1, 'Pellentesque ut', 0),
(421, 58, '2018-03-15', NULL, NULL, 0, 0, 0, 1, 0, 'odio. Aliquam vulputate ullamcorper magna. Sed eu', 0),
(422, 102, '2018-03-03', NULL, NULL, 1, 1, 1, 1, 1, 'Integer urna. Vivamus molestie dapibus ligula. Aliquam erat volutpat. Nulla', 0),
(423, 72, '2018-03-07', NULL, NULL, 0, 1, 1, 1, 1, 'iaculis odio. Nam interdum enim non', 0),
(424, 7, '2018-06-14', NULL, NULL, 0, 0, 1, 1, 1, 'in faucibus orci luctus et ultrices posuere cubilia Curae Phasellus', 0),
(425, 34, '2018-07-16', NULL, NULL, 1, 1, 1, 1, 0, 'nec mauris blandit mattis. Cras eget nisi dictum augue malesuada', 0),
(426, 72, '2018-07-10', NULL, NULL, 1, 1, 0, 0, 1, 'consectetuer ipsum nunc id enim. Curabitur massa.', 0),
(427, 69, '2018-07-24', NULL, NULL, 1, 0, 1, 0, 0, 'scelerisque scelerisque dui.', 0),
(428, 46, '2018-07-11', NULL, NULL, 0, 0, 1, 0, 1, 'Quisque ornare tortor at risus.', 0),
(429, 73, '2018-07-18', NULL, NULL, 1, 0, 0, 0, 0, 'quam. Curabitur vel lectus. Cum sociis', 0),
(430, 22, '2018-06-01', NULL, NULL, 0, 0, 0, 1, 0, 'orci tincidunt adipiscing. Mauris molestie pharetra nibh.', 0),
(431, 83, '2018-03-27', NULL, NULL, 1, 1, 1, 1, 0, 'Quisque libero lacus, varius et, euismod et, commodo', 0),
(432, 60, '2018-02-23', NULL, NULL, 0, 0, 1, 0, 1, 'vel, faucibus id, libero. Donec', 0),
(433, 97, '2018-07-06', NULL, NULL, 0, 0, 0, 0, 0, 'dapibus gravida. Aliquam tincidunt, nunc ac', 0),
(434, 56, '2018-02-09', NULL, NULL, 0, 1, 0, 0, 1, 'semper, dui', 0),
(435, 71, '2018-05-03', NULL, NULL, 0, 0, 0, 1, 1, 'Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna.', 0),
(436, 59, '2018-08-03', NULL, NULL, 0, 1, 1, 1, 0, 'Donec fringilla. Donec feugiat metus sit amet ante. Vivamus', 0),
(437, 13, '2018-07-28', NULL, NULL, 0, 1, 0, 0, 0, 'aliquam iaculis, lacus pede sagittis augue, eu tempor', 0),
(438, 69, '2018-02-15', NULL, NULL, 0, 1, 1, 1, 1, 'montes, nascetur', 0),
(439, 82, '2018-06-18', NULL, NULL, 0, 0, 0, 1, 1, 'nibh', 0),
(440, 27, '2018-02-08', NULL, NULL, 0, 1, 0, 1, 0, 'mollis. Duis sit amet diam eu', 0),
(441, 39, '2018-08-03', NULL, NULL, 0, 1, 0, 1, 0, 'faucibus lectus, a', 0),
(442, 29, '2018-06-24', NULL, NULL, 1, 0, 0, 1, 1, 'sociis natoque penatibus et magnis', 0),
(443, 68, '2018-07-16', NULL, NULL, 1, 0, 0, 1, 0, 'facilisis vitae, orci. Phasellus dapibus quam quis diam.', 0),
(444, 6, '2018-03-03', NULL, NULL, 1, 1, 0, 1, 1, 'nec ante', 0),
(445, 73, '2018-02-14', NULL, NULL, 0, 0, 1, 0, 1, 'malesuada id, erat. Etiam vestibulum massa', 0),
(446, 79, '2018-08-04', NULL, NULL, 1, 0, 1, 1, 1, 'Lorem ipsum', 0),
(447, 60, '2018-08-14', NULL, NULL, 1, 0, 1, 1, 1, 'Proin nisl sem, consequat nec, mollis vitae, posuere', 0),
(448, 48, '2018-03-18', NULL, NULL, 0, 1, 1, 0, 1, 'accumsan convallis,', 0),
(449, 23, '2018-05-27', NULL, NULL, 1, 1, 1, 0, 0, 'eu tellus. Phasellus elit pede, malesuada vel, venenatis vel, faucibus', 0),
(450, 76, '2018-04-26', NULL, NULL, 0, 0, 0, 0, 1, 'Nam consequat dolor vitae dolor. Donec', 0),
(451, 35, '2018-02-02', NULL, NULL, 1, 0, 1, 1, 0, 'malesuada', 0),
(452, 104, '2018-07-11', NULL, NULL, 1, 1, 1, 0, 1, 'tincidunt pede ac', 0),
(453, 65, '2018-05-09', NULL, NULL, 0, 1, 1, 0, 1, 'et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim', 0),
(454, 97, '2018-05-16', NULL, NULL, 1, 0, 1, 1, 0, 'non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper', 0),
(455, 43, '2018-04-14', NULL, NULL, 0, 0, 0, 1, 1, 'pede. Cum sociis natoque penatibus et magnis', 0),
(456, 4, '2018-06-22', NULL, NULL, 1, 1, 1, 1, 0, 'nec, leo. Morbi neque tellus,', 0),
(457, 60, '2018-01-07', NULL, NULL, 0, 1, 0, 0, 1, 'Fusce', 0),
(458, 45, '2018-03-17', NULL, NULL, 1, 1, 1, 0, 1, 'ultricies adipiscing,', 0),
(459, 88, '2018-06-29', NULL, NULL, 0, 1, 1, 0, 1, 'Duis volutpat nunc sit amet metus. Aliquam erat', 0),
(460, 83, '2018-08-18', NULL, NULL, 0, 1, 1, 1, 1, 'faucibus orci', 0),
(461, 102, '2018-04-16', NULL, NULL, 1, 0, 0, 1, 1, 'rutrum,', 0),
(462, 31, '2018-08-03', NULL, NULL, 1, 1, 1, 0, 0, 'purus. Nullam scelerisque neque sed sem egestas blandit. Nam', 0),
(463, 11, '2018-04-14', NULL, NULL, 1, 1, 0, 1, 1, 'pede, malesuada', 0),
(464, 67, '2018-02-01', NULL, NULL, 0, 1, 1, 1, 1, 'quis, tristique ac,', 0),
(465, 64, '2018-01-08', NULL, NULL, 1, 1, 0, 0, 1, 'Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede.', 0),
(466, 67, '2018-06-29', NULL, NULL, 1, 1, 1, 0, 1, 'dolor, nonummy ac, feugiat non, lobortis quis,', 0),
(467, 53, '2018-02-02', NULL, NULL, 0, 0, 1, 0, 0, 'sem, consequat nec, mollis vitae, posuere at, velit.', 0),
(468, 86, '2018-03-02', NULL, NULL, 0, 0, 1, 0, 0, 'sed orci', 0),
(469, 89, '2018-06-16', NULL, NULL, 0, 1, 1, 0, 1, 'sodales', 0),
(470, 10, '2018-04-17', NULL, NULL, 1, 0, 0, 0, 1, 'Nunc pulvinar arcu et pede. Nunc', 0),
(471, 76, '2018-07-18', NULL, NULL, 1, 0, 1, 1, 0, 'molestie pharetra nibh.', 0),
(472, 89, '2018-03-06', NULL, NULL, 1, 1, 1, 0, 1, 'senectus et', 0),
(473, 82, '2018-08-17', NULL, NULL, 0, 1, 1, 1, 0, 'magna. Duis dignissim tempor arcu. Vestibulum ut', 0),
(474, 44, '2018-06-02', NULL, NULL, 0, 0, 0, 1, 0, 'iaculis, lacus pede sagittis augue, eu', 0),
(475, 22, '2018-03-11', NULL, NULL, 1, 1, 0, 1, 0, 'orci. Phasellus dapibus quam', 0),
(476, 5, '2018-04-25', NULL, NULL, 1, 0, 0, 1, 1, 'velit justo nec', 0),
(477, 56, '2018-06-24', NULL, NULL, 0, 1, 1, 0, 1, 'bibendum fermentum metus.', 0),
(478, 43, '2018-04-07', NULL, NULL, 0, 1, 0, 1, 0, 'cursus, diam at pretium aliquet, metus', 0),
(479, 51, '2018-01-07', NULL, NULL, 0, 0, 1, 0, 0, 'vitae purus gravida sagittis. Duis gravida. Praesent eu nulla at', 0),
(480, 12, '2018-04-11', NULL, NULL, 0, 0, 0, 1, 1, 'elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla', 0),
(481, 76, '2018-06-24', NULL, NULL, 1, 0, 1, 1, 0, 'adipiscing', 0),
(482, 23, '2018-05-17', NULL, NULL, 1, 1, 1, 0, 1, 'dui augue eu tellus. Phasellus elit', 0),
(483, 61, '2018-06-20', NULL, NULL, 0, 1, 0, 0, 1, 'Aliquam', 0),
(484, 79, '2018-06-13', NULL, NULL, 0, 1, 1, 0, 0, 'cursus', 0),
(485, 2, '2018-02-24', NULL, NULL, 1, 0, 1, 1, 0, 'magna.', 0),
(486, 35, '2018-01-31', NULL, NULL, 1, 0, 1, 0, 1, 'Sed eu nibh vulputate mauris sagittis placerat. Cras dictum', 0),
(487, 90, '2018-02-23', NULL, NULL, 1, 0, 0, 0, 0, 'vel arcu. Curabitur ut odio vel est tempor bibendum.', 0),
(488, 103, '2018-07-12', NULL, NULL, 0, 0, 1, 1, 1, 'hendrerit consectetuer, cursus', 0),
(489, 30, '2018-07-30', NULL, NULL, 0, 0, 0, 1, 0, 'facilisis. Suspendisse commodo tincidunt nibh. Phasellus', 0),
(490, 75, '2018-03-09', NULL, NULL, 0, 1, 1, 0, 1, 'eget odio. Aliquam vulputate ullamcorper magna. Sed eu eros. Nam', 0),
(491, 56, '2018-07-02', NULL, NULL, 0, 1, 0, 0, 1, 'eu, euismod ac,', 0),
(492, 74, '2018-05-12', NULL, NULL, 1, 0, 1, 0, 0, 'sed pede. Cum sociis natoque penatibus et', 0),
(493, 8, '2018-07-27', NULL, NULL, 0, 1, 1, 0, 0, 'et ultrices posuere cubilia Curae Donec tincidunt. Donec', 0),
(494, 49, '2018-07-09', NULL, NULL, 1, 0, 0, 0, 0, 'fermentum metus.', 0),
(495, 38, '2018-01-24', NULL, NULL, 1, 1, 0, 0, 0, 'dignissim. Maecenas ornare egestas ligula. Nullam', 0),
(496, 72, '2018-02-08', NULL, NULL, 1, 0, 1, 1, 1, 'Sed pharetra, felis eget varius ultrices, mauris', 0),
(497, 2, '2018-07-09', NULL, NULL, 1, 1, 0, 0, 0, 'dolor. Nulla', 0),
(498, 73, '2018-01-21', NULL, NULL, 0, 1, 0, 1, 1, 'Duis', 0),
(499, 87, '2018-08-15', NULL, NULL, 1, 0, 1, 0, 1, 'justo', 0),
(500, 101, '2018-02-12', NULL, NULL, 1, 0, 0, 0, 1, 'ultricies dignissim', 0),
(501, 107, '2018-08-20', 'XXXX', '10-696', 1, 1, 0, 1, 0, 'Accompanied by guardian', 1),
(502, 107, '2018-08-20', 'XXXX', '10-696', 1, 1, 0, 1, 0, 'Accompanied by guardian', 1),
(503, 107, '2018-08-20', 'XXXX', '10-696', 1, 1, 0, 1, 1, 'Accompanied by adult', 0),
(504, 59, '2018-10-08', 'XXXX', '10-696', 1, 1, 1, 1, 1, 'Asdf', 0);

-- --------------------------------------------------------

--
-- Table structure for table `visits_datamod`
--
-- Creation: Aug 18, 2018 at 04:51 PM
--

CREATE TABLE IF NOT EXISTS `visits_datamod` (
  `visit_id` int(11) NOT NULL,
  `visitor_id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `form_signed` tinyint(1) NOT NULL COMMENT '0 no; 1 yes',
  `butanding` tinyint(1) NOT NULL COMMENT 'butanding activity',
  `girawan` tinyint(1) NOT NULL COMMENT 'girawan activity',
  `firefly` tinyint(1) NOT NULL COMMENT 'firefly activity',
  `island_hop` tinyint(1) NOT NULL COMMENT 'island_hop activity',
  `visit_remarks` text COLLATE utf8_unicode_ci NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`visit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='temporary storage prior to supervisor approval';

-- --------------------------------------------------------

--
-- Table structure for table `ws_photoid`
--
-- Creation: Aug 19, 2018 at 09:06 AM
--

CREATE TABLE IF NOT EXISTS `ws_photoid` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `report_date` date NOT NULL,
  `season` year(4) DEFAULT NULL,
  `total_ph_ws` smallint(5) unsigned NOT NULL,
  `total_donsol_ws` smallint(5) unsigned NOT NULL,
  `season_total` smallint(5) unsigned NOT NULL,
  `new_sighting_count` smallint(5) unsigned NOT NULL,
  `resighting_count` smallint(5) unsigned NOT NULL,
  `ws_remarks` text NOT NULL,
  `trash_flag` tinyint(4) NOT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ws_photoid`
--

INSERT INTO `ws_photoid` (`report_id`, `report_date`, `season`, `total_ph_ws`, `total_donsol_ws`, `season_total`, `new_sighting_count`, `resighting_count`, `ws_remarks`, `trash_flag`) VALUES
(1, '2018-08-01', 2018, 1298, 494, 16, 13, 3, 'wsphotoid@yahoo.com', 0),
(2, '2018-08-05', 2018, 1298, 494, 18, 13, 5, 'wsphotoid@yahoo.com', 0),
(3, '2018-08-07', 2018, 1298, 494, 20, 13, 7, 'Change again', 1),
(4, '2018-08-10', 2018, 1298, 494, 21, 13, 8, 'Changing remarks again and again', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
